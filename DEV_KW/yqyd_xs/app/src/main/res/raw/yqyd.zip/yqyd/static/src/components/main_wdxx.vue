<template>
	<div>
		<!-- 头部 -->
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback"></image>
			<text class="top_name">我的消息</text>
		</div>
		<!-- 消息列表 -->
		<div class="info">		
		    <image src="../static/images/head.png" class="info_img" />			
			<div>
				<div class="name">
					<text style="color: #70a1e8;font-size: 32px;flex:1;">系统消息</text>
					<text style="font-size: 25px; color:#666;margin-top:4px;flex: 1;">3月29日 13：32</text>
				</div>
				<div class="xx_main">
					<text style="font-size: 32px; color:#666;">一起阅读家长正式上线啦！</text>
				</div>
			</div>
		</div>
		<div class="info">		
		    <image src="../static/images/head.png" class="info_img" />			
			<div>
				<div class="name">
					<text style="color: #70a1e8;font-size: 32px;flex:1;">系统消息</text>
					<text style="font-size: 25px; color:#666;margin-top:4px;flex: 1;">3月29日 13：32</text>
				</div>
				<div class="xx_main">
					<text style="font-size: 32px; color:#666;">一起阅读家长正式上线啦！</text>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	export default {
		data(){
			return {

			}
		},
		methods:{
			//返回上一级
			goback () {
				this.$router.go(-1);
			}
		}
	}
</script>
<style scoped>
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.info{
		width: 750px;
		height: 130px;
		/* background-color: orange; */
		border-bottom-style: solid;
		border-bottom-width: 1px;
		border-bottom-color: #e7e7e7;
		flex-direction: row;
		align-items: center;
		padding-left: 30px;
		box-sizing: border-box;
	}
	.info_img{
		width: 100px;
		height: 100px;

	}
	.name{
		width: 600px;
		margin-left: 20px;
		flex-direction: row;
		justify-content: space-between;
	}
	.xx_main{
		margin-left: 20px;
		margin-top: 10px;
	}
</style>