var host='http://192.168.8.6:8280/v1/';
// var host='http://m.kiway.cn/yqyd/v1/';
var urls={
	// 班级列表
	bjlb: 'app/class/myclass',
	// 排名列表
	pmlb: 'app/class/classInfo',
	// 阅读教研分类列表
	fllb: 'app/res/module',
	// 阅读教研列表
	zylb: 'app/res/list',
	// 阅读教研详情
	zyxqlb: 'app/res/info',
	// 阅读资讯
	ydzx: 'app/information/',
	// 阅读资讯详情
	zxxq: 'app/information/{id}',
	// 书库年级列表
	sknj: 'app/book/grade',
	// 书库类别列表
	sklb: 'app/book/module',
	// 报告列表
	bglb: 'app/report/planReport',
	// 报告概括
	bggk: 'app/report/reportInfo',
	// 报告详情
	bgxq: 'app/report/reportDetail'
}
export default {
	host: host,
	url: urls
}