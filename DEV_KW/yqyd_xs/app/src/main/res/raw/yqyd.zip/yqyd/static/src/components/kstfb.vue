<template>
	<div>
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback" /> 
			<text class="top_name">我的任务</text>
		</div>
			<div class="tab">
				<text class="tab_li" @click="openYdrw">阅读任务</text>
				<text class="tab_li tab_yes" @click="onpeKstfb" >考试提分宝</text>
			</div>
			<div class="type">
				<div class="type_li" @click="fn()" style=" border-right-color: #e6e6e6; border-right-style: solid; border-right-width: 1px; ">
					<text style="font-size: 32px;color: #666; ">类型</text>
					<image src="../static/images/ico_17.png" class="type_img" />
				</div>
				<div class="type_li"  @click="show()" >
					<text style="font-size: 32px;color: #666; ">状态</text>
					<image src="../static/images/ico_17.png" class="type_img" />
				</div>
			</div>
			<!--<div class="type_li1" v-if="willShow2" >
				<text class="type_ling type_yes" >全部</text>
				<text class="type_ling" >未完成</text>
				<text class="type_ling" >已过期</text>
				<text>已完成</text>
			</div>
			<div class="type_li1 type_li2" v-if="willShow">
				<text class="type_ling ">全部</text>
				<text class="type_ling type_yes">每日一练</text>
				<text class="type_ling">每周一课</text>
				<text class="" >其他</text>
			</div>-->
		<scroller>
				<div class="jrrw">
					<!-- 任务列表 -->
					<div class="jrrw_list"  :class="['bj' + kstfb.state]"  v-for="kstfb in kstfb_list">
						<div class="jrrw_info">
							<text class="rw_title">{{kstfb.title}}</text>
							<div class="rw_time"><text style="font-size: 26px; color: #808080;">截止：{{kstfb.time}}</text> <text style="font-size: 26px; color: #808080;">{{kstfb.name}}</text></div>
						</div>
						<!--<router-link class="c_bg" :to="kstfb.href">-->
						<div class="c_bg">
							<text class="c_bg_btn" :class="['c_bg_btn' + kstfb.state]"  >{{kstfb.stateName}}</text>
							<text class="stateName" v-if="kstfb.stateName=='补做'">逾期未提交</text>
						</div>
						<!--</router-link>-->
						<image src="../static/images/xs_pic_newR.png" class="newR"  v-if="kstfb.new" />
					</div>
				</div>
			</scroller>

	</div>
</template>

<script>
	export default {
		data(){
			return {
				willShow:false,
				willShow2:false,
				kstfb_list: [
					{title: '每日一练', time: '05-05 23:59',new: true,state:'0',stateName:'前 往',href: '/kstfb/mr'},
					{title: '每日一练', time: '10-08 23:59',new: false,state:'2',stateName:'已完成',href: '/kstfb/mr'},
					//{title: '每月一测', time: '02-27 23:59',new: false,state:'2',stateName:'已完成',href: '/kstfb/mr' },
					{title: '每日一练', time: '01-03 23:59',new: false,state:'1',stateName:'补做',href: '/kstfb/mr'}
				]
			}
		},
		methods: {
	        fn:function(){
	          if(this.willShow==true){
	            this.willShow=false;
	          }else{
	            this.willShow=true
	          }
	        },
	        show:function(){
	          if(this.willShow2==true){
	            this.willShow2=false;
	          }else{
	            this.willShow2=true
	          }
	        },
			 goback () {
		      	//this.$router.go(-1);
		      	this.$router.push('/index');
			},openKstfb(){
	        	this.$router.push('/kstfb');
	        },
	        openYdrw(){
	        	this.$router.push('/ydrw');
	        }
	
		}
	}
</script>

<style scoped>
	 .top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.content{
		width: 750px;
		background-color: #fff;
		padding-bottom: 30px;
	}
	.tab{
		height: 70px; 
        margin-top: 12px;
        margin-bottom: 12px;
        margin-right: 60px;
        margin-left: 60px;
		border-width: 2px;
		border-style: solid;
		border-color:#d9e8fd;
		border-radius: 35px; 
		
		flex-direction: row;
		align-items: center;
		justify-content: center;
	}
	.tab_li{
		flex: 1;
		vertical-align: middle;
		height: 70px; 
		line-height:65px; 
		text-align:center; 
		font-size: 34px;
		color: #666;
	}
	.tab_yes{
		background-color: #d9e8fd; 
		border-radius: 35px; 
		color: #6fa1e8;	
	}
	
.type{
		height: 85px; 
		width: 750px;
		flex-direction: row;
		align-items: center; 
		justify-content: center; 
		border-bottom-style: solid;
		border-bottom-color: #e6e6e6;
		border-bottom-width: 1px;
		border-top-style: solid;
		border-top-color: #e6e6e6;
		border-top-width: 1px;	
	}
	.type_li{
		position: relative; 
		flex: 1;
		padding-left: 40px;
		padding-right: 40px; 
		margin-top: 8px;
		flex-direction: row;
		align-items: center; 
		justify-content: space-between; 
	}
	.type_img{
		width: 35px; 
		height: 18px;
	}
	.type_li1{
		position: absolute;
		right: 0;
		z-index: 99; 
		background-color: #fff;  
		width: 50%;
		font-size: 30px;
		height:284px; 
		line-height: 70px;
		flex-direction: column; 
		align-items: center; 
		justify-content: center; 
		text-indent: 0.3px; 
		border-style: solid;
		border-color: #e6e6e6;
		border-width: 1px;
		color: #666; 
	}
	.type_li2{
		height:214px; 
		left: 0;
	}
	.type_ling {
		border-bottom-style: solid;
		border-bottom-color: #e6e6e6;
		border-bottom-width: 1px;
	}
	.type_yes{ 
		background-color: #70a1e8;
		color: #fff;	
	 }

	.jrrw{
		width: 750px;
		background-color: #fff;
		padding-top: 30px;
		padding-bottom: 30px;
	}
	.title_img{
		background-color: #70a1e8; 
		margin-right: 10px;}
	.jrrw_list{
		overflow: hidden;
		position: relative;
		z-index: 2;
		width: 710px; 
		margin-left: 20px;
		margin-right: 20px;
		background-color:#f1f6fd;
		border-width: 1px;
		border-style: solid;
		border-color:#d9e8fd;
		border-radius: 12px;
		margin-bottom: 20px;
	}
	.newR{
		position: absolute;
		top: -2px;
		right: -2px;
		width: 75px; height:75px;
	}

	.jrrw_info{
		/*float: left;*/
		width: 540px;
		padding-top: 20px;
		padding-bottom: 20px;
		padding-left: 30px;
		padding-right: 30px;
	}
	.rw_title{
		font-size: 34px;
		line-height: 38px;
		color: #666;
	}
	.rw_time{ 
		flex-direction: row;
		align-items: center; 
		justify-content: space-between;
		height: 40px;
		margin-top: 5px;
	}

	.c_bg{
		position: absolute;
		top: 35px;
		right: 0px;
		bottom: 0px;
		width: 150px;
		text-align: center;
	}
	.c_bg_btn{
		text-align: center;
		width: 110px;
		padding-top: 5px;
		padding-bottom:5px;
		font-size: 28px; 
		border-radius: 8px;
		background-color: #70a1e8;
		color: #fff;
		margin-bottom: 10px;
	}
	.bj0{ background-color: #f1f6fd;  }
	
	.bj1{ 
		background-color: #fff; 
		border:#d9e8fd 0.01rem solid; 
	}
	.bj2{ background-color: #fff;  }
	.c_bg_btn2{
		background-color: #fff; 
		color: #70a1e8;
		border-width: 1px;
		border-style: solid;
		border-color:#70a1e8;
	}
	.c_bg_btn1{
		border:#e6e6e6 1px solid; 
		border-width: 1px;
		border-style: solid;
		border-color:#e6e6e6;
		background-color: #fff; 
		color: #999;
	}
	.stateName{
		position: absolute; 
		bottom: -20px; 
		font-size: 22px; 
		color:#f60; 
		left: 0;
	}
</style>