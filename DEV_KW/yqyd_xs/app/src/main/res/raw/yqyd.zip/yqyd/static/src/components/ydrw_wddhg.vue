<template>
	<div style=" background-color: #fafafa; ">
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback"  @click="goback" />
			<text class="top_name">我的读后感</text>
		</div>
		<scroller>
		<div class="main">
			<div class="title">
				<text style=" font-size: 40px; color: #333333;">{{redList.title}}</text>
			</div>
			<div class="content">
				<text style="font-size: 35px; color: #666666;" >{{redList.content}}</text>
				<div class="voice"  @click="playVoice(redList.voice)"  v-if="redList.duration">
					<text style="font-size: 34px; color: #6fa1e8; ">{{redList.duration}}'</text><image :src="VoicePic" class="pic_yy" />
				</div>
				<div class="photoList">
					<div style="padding:10px; " v-for="(lPic,index) in piclist"  @click="enlargePic(lPic,index)">
						<image :src="lPic" style=" width: 152px; height: 150px; "></image>
					</div>
				</div>
				<text class="grade" v-if="redList.score">{{redList.score}}分</text>
			</div>
			
			<text class="tlt">老师评语</text>
			<div class="remark">
				<div style="flex: 1;">
					<image class="remark_pic" :src="redList.avatar" />
					<text class="name">{{redList.teaName}}</text>
	            </div>
	             <div style="flex: 3;">
					<div class="voice"  @click="playTvoice(redList.checkVoice)" v-if="redList.checkDuration">
						<text style="font-size: 34px; color: #6fa1e8; ">{{redList.checkDuration}}'</text><image :src="VoicePic"  class="pic_yy" />
					</div>	
					<text class="r_info">{{redList.checkContent}}</text>
				</div>
			</div>
		</div>
		</scroller>
	</div>
</template>

<script>
	const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				VoicePic:'../static/images/xs_pic_yy.png',
				checkYes:'../static/images/xs_pic_1.gif',
				checkNo:'../static/images/xs_pic_yy.png',
				redList:{},
				piclist:[],
				loginA:'',
			 /*   rwId:'',
			    bId:'',*/
			}
		},
		methods: {
			 goback () {
			 	var sjevent = weex.requireModule('SJevent');
			    if(sjevent){
			    	sjevent.StopVoice();
			    }
		        this.$router.go(-1);
		    },
		     playVoice(url){
	        	var sjevent = weex.requireModule('SJevent');
	        	if(sjevent){
					sjevent.PlayVoice( url ,function(ret){
						if(this.VoicePic==this.checkYes && ret=='ok'){
							this.VoicePic=this.checkNo;
						}else{
							this.VoicePic=this.checkYes;
						}
					}) ;	
				}
	        },
	        playTvoice(url){
	        	var sjevent = weex.requireModule('SJevent');
	        	if(sjevent){
					sjevent.PlayVoice( url ,function(ret){
						if(this.VoicePic==this.checkYes && ret=='ok'){
							this.VoicePic=this.checkNo;
						}else{
							this.VoicePic=this.checkYes;
						}
					}) ;
				}	
	        },
	        enlargePic(lPic,index){
	        	var sjevent = weex.requireModule('SJevent');
				sjevent.showPhoto(lPic,index); 
	        }
		},
		created: function(){
			 var self = this;
			 	//this.zrw=self.$route.query.access;
               //self.wwc=self.$route.query.finish;

               //console.log(self.wwc);
              // console.log(self.zrw);
            storage.getItem('username',function(e){  //从缓存中取userId
            	self.loginA = e.data;
            	kwz.fetch({
			    	url : '/app/student/feeling/myfeeling?loginAccount='+self.loginA +'&planId='+self.$route.query.planId+'&bookId='+self.$route.query.bookId,
			    	method:'POST',
			    	type:'json',
			    	success : function(ret){
			    		var red = ret.data.result;
			    		self.piclist=red.img.split(',');
			    		//console.log('------------------'+self.piclist);
			    		self.redList=eval(red);
			    	
			    	}
				})
			})

        }   
	}
</script>

<style scoped>
    .top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.main{
		background-color: #fff;
		width: 750px;
	}
	.title{
		flex-direction: row;
		align-items: center;
		justify-content: center;
		width: 750px;
		height: 90px;
		background-color: #fff;
	}
	.content{
		width: 750px;
		padding-left: 35px;
		padding-bottom: 40px;
		padding-right: 35px;
		background-color: #fff;
		border-bottom-width: 1px;
		border-bottom-style: solid;
		border-bottom-color: #e7e7e7;
	}
	.grade{
		text-align: right;
		font-size: 46px;
		color: #f66c6c;
		font-weight: 600;
		margin-top: 80px;
		margin-right: 40px;
	}
	.tlt{
		width: 750px;
		padding: 30px;
		font-size: 36px;
		color: #999999;
		background-color: #f3f3ef;
	}
	.remark{
		width: 750px;
		padding: 30px;
		flex-direction: row;

	}
	.remark_pic{
		width: 80px;
		height: 80px;
		border-radius: 40px;
		float: left;
		margin-right:20px;
	}
	.name{
		margin-right: 25px;
		float: left;
		font-size: 35px;
		color: #79a8ec;
		height: 80px;
		line-height: 80px;
	}
	.photoList{
		flex-direction: row;
		flex-wrap:wrap;
		margin-top: 20px;
	}
	.voice{
		width: 270px; 
		height: 80px; 
		flex-direction: row;
		align-items: center;
		justify-content: space-between;
		border-style: solid;
		border-color: #e8e8e8;
		border-width: 1px;
		border-radius: 8px; 
		background-color: #f5f5f5; 
		margin-top: 20px;
		padding-left: 20px;
		padding-right: 20px;
	}
	.pic_yy{
		width: 20px;
		height: 30px;
	}
	
	.r_info{
		font-size: 34px;
		color: #333333;
		margin-top: 20px;
	}
</style>