<template>
	<div id="ydzx" style=" background-color: #fff; font-family: 黑体; ">
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback" />
			<text class="top_name">{{ydzxXq.title}}</text>
			<image src="../static/images/ico_2101.png" class="send"  />
		</div>
		<scroller>
		<div class="ydzx_main">
			<div class="ydzx_l">
				<text class="ydzx_titil" >{{ydzxXq.title}}</text>
				<div class="ydzx_time"><text style=" color: #666; font-size: 30px;" >{{ydzxXq.createDate}}</text><text style="color:#6fa1e8; font-size: 30px; ">{{ydzxXq.tags}}</text></div>
			</div>
			<image :src="ydzxXq.image" class="ydzx_img" v-if="ydzxXq.image"></image>
			<div class="ydzx_text">
				<text style=" color: #666; font-size: 36px; text-align:justify; line-height: 45px; " >{{ydzxXq.content}}</text>
			</div>
		</div>
		</scroller>
	</div>
</template>
<script>
    const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				// 活动列表
				ydzxXq: {}
			}
		},
		name: 'ydzx_xq',
		methods: {
		    goback () {
		       this.$router.go(-1);
		    }
		},
		created: function(){
			 var self = this;
			console.log(self.$route.query.id);
            	  kwz.fetch({
			    	url : '/app/information/'+self.$route.query.id,
			    	method:'POST',
			    	type:'json',
			    	//data:'loginAccount=12&token=123123&id=1',
			    	success : function(ret){
			    		var datas = ret.data.result;
			    		self.ydzxXq=eval(datas);
			    	
			    	}
			  })
     	
		
		}
	}
</script>
<style scoped >
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		width: 550px;
		margin-left:100px;
		margin-right:100px;
		text-overflow: ellipsis;
		lines:1;
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.send{
		position: absolute;
		width: 42px;
		height:42px;
		top: 22px;
		right: 27px;
	}
	.ydzx_main{
		width: 750px; 
	}
	.ydzx_l{
		padding-top: 20px;
		padding-bottom: 20px;
		padding-left: 30px;
		padding-right: 30px;
		width: 750px;
	}
	.ydzx_img{
		width: 690px;
		height: 360px;
		margin-left: 30px;
		margin-right: 30px;
	}
	.ydzx_text{
		padding: 30px;
		margin-bottom: 120px;
		background-color: #fff;
	}
	.ydzx_titil{
		color:#333; 
		font-size:40px; 
		line-height: 80px; 
		overflow:hidden; 
		text-overflow:ellipsis; 
		white-space:nowrap;
	}
	.ydzx_time{
		color:#b7b7b7; 
		font-size: 35px;
		line-height: 60px;
		flex-direction: row; 
		align-items: center;
		justify-content: space-between;
	}
</style>