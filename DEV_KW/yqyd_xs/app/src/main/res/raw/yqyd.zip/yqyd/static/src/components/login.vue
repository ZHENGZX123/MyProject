<template>
	<div id="ydzx" style=" background-color: #6fa1e8; ">
		<image src="../static/images/login01.png" class="bj_pic" />
		<div class="main">
			<!--<text style=" font-size: 45px; color: #fff; ">用户登录</text>-->
			<div class="inputK">
				<input type="text" v-model="username" placeholder="请输入账号" class="input" />
			</div>
			<div class="inputK">
				<input type="password" v-model="password" placeholder="请输入密码" class="input" />
			</div>
			<div class="mm_line" @click="checkClick"  >
				<image :src="checkes" style=" width: 45px; height: 45px; " />
				<text class="name">&nbsp;记住密码？</text>
			</div>
			<text @click="openIndex" class="btn" >登   录</text>
			<div class="mm_line"  >
				<!--<text class="name" @click="openAdmin" >忘记帐号？</text>-->
				<text class="name" @click="openPwd" >忘记密码？</text>
			</div>
		</div>
	
	</div>
</template>
<script>
    const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				username:'',
				password:'',
				schoolCode:'',
				checkes:'../static/images/checkbox_no.png',
				checkYes:'../static/images/checkbox_yes.png',
				checkNo:'../static/images/checkbox_no.png',
			}
		},
		name: 'ydzx_xq',
		methods: {
			checkClick: function(){
				if(this.checkes==this.checkYes){
					this.checkes=this.checkNo;
				}else{
					this.checkes=this.checkYes;
				}
			},
		    openIndex : function(){
	        	 var self = this; 
                if(self.username==""){
                    modal.alert({
                        message:'账号不能为空，请输入',
                        okTitle:'好的'
                    },function(){});
                    return;
                }
                if(self.password==''){
                	 modal.alert({
                        message:'密码不能为空，请输入',
                        okTitle:'好的'
                    },function(){});
                    return;
                }
            	kwz.fetch({
			    	url : 'http://yqyd.qgjydd.com/yqyd/app/stuLogin?username=' + self.username + "&password=" +self.password,
			    	method:'POST',
			    	type:'json',
			    	ip:true,
			    	success : function(ret){
			    		console.log(ret);
			    		if( ret && ret.data.errcode == 200){			    	
			    			storage.setItem('username',self.username);
			    			storage.setItem('schoolCode',ret.data.schoolCode,function(e){});
			    			//debugger
			    			if (self.checkes==self.checkYes) {
			    				storage.setItem('password',self.password,function(e){});
			    				storage.setItem('checkes',self.checkes,function(e){});
			    				

			    			}else{
			    				storage.removeItem('password',function(e){});
			    				storage.removeItem('checkes',function(e){});
			    				storage.removeItem('username',function(e){});
			    			}
			    			//self.$router.replace('/index');
			    			
			    			if(false){
			    			//if(true){
								var sjevent = weex.requireModule('SJevent');
								sjevent.loginSuccess(self.username);
							}else{
								self.$router.replace('/index');
							}
			    		}else{
							modal.toast({	
							  message: ret.data.errmsg ,
							  duration: 0.3,
							  okTitle:'好的'
							});
			    		}
			    	}
			  })    
	        },
	        /*openAdmin(){
	        	this.$router.push('/wjzh');
	        },*/
	         openPwd(){
	        	this.$router.push('/wjmm');
	        }
		},
		created : function(){
			var self=this;
			var pwd,acct,imgPic;
			storage.getItem('checkes',function(e){  //从缓存中取password
				imgPic=e.data;
				if(imgPic!='undefined'){
					self.checkes=imgPic;
					if (imgPic==self.checkYes) {
					    storage.getItem('password',function(e){  //从缓存中取password
		            		pwd = e.data;
		            		self.password= pwd;		
		            	});
		            	storage.getItem('username',function(e){  //从缓存中取username
		            		acct = e.data;
		            		self.username= acct;		
		            	});		
					}
				}
			});
		}
	}
</script>
<style scoped >
	.bj_pic{
		width: 750px; 
		height: 1240px; 
		max-height: 1400px;
		position: absolute; 
	}
	.main{
		position: relative; 
		z-index: 999; 
		padding-top:150px;  
		width: 750px; 
		flex-direction: column; 
		align-items: center;
		justify-content: center;
	}
	.inputK{
		width: 620px; 
		height:100px; 
		margin-top: 50px;  
		color: #fff; 
		background-color: rgba(255,255,255,0.2); 
		position:static; 
		zoom:1; 
		border-radius: 55px;  
		border-color: #6fa1e8;
		border-style: solid;
		border-width: 1px; 
	}
	.input{
		width: 620px; 
		height: 100px; 
		font-size: 36px; 
		padding-left:40px; 
		padding-right: 20px; 
		position: relative; 
		color: #6fa1e8;
		background-color: none;
		border-radius: 55px;  
		border:none; 
	}
	.mm_line{
		width: 620px; 
		height: 120px;
		flex-direction: row; 
		align-items: center;
	}
	.name{
		 flex: 1; 
		 font-size: 34px;
		 color: #6fa1e8;
	}
	.btn{
		width: 620px; 
		margin-top: 30px; 
		text-align: center;
		padding-top: 25px; 
		padding-bottom: 25px; 
		border-radius: 55px; 
		color: #6fa1e8; 
		font-size: 40px;  
		background-color: rgba(255,255,255,0.2); 
		border-color: #6fa1e8;
		border-style: solid;
		border-width: 1px; 
	}
</style>