// import Vue from 'vue'
import Router from 'vue-router'
/*import StoriesView from './views/StoriesView.vue'
import ArticleView from './views/ArticleView.vue'
import CommentView from './views/CommentView.vue'
import UserView from './views/UserView.vue'*/

Vue.use(Router)

export default new Router({
  // mode: 'abstract',
  routes: [
    { path: '/', name: 'login', component: require('./components/login.vue')},
    { path: '/wjmm', name: 'wjmm', component: require('./components/forget_pwd.vue')},
   // { path: '/wjzh', name: 'wjzh', component: require('./components/forget_admin.vue')},
  
   // { path: '/', name: 'index', component: require('./components/index.vue')},
    { path: '/index', name: 'index', component: require('./components/index.vue')},
   
    // 阅读任务
    { path: '/ydrw', name: 'ydrw', component: require('./components/ydrw.vue')}, 
    // 任务详情
    { path: '/ydrw/ckjh', name: 'ydrw_jh', component: require('./components/ydrw_jh.vue')}, 
     // 阅读任务详情
    { path: '/ydrw_xq', name: 'ydrw_xq', component: require('./components/ydrw_xq.vue')}, 
    // 阅读任务 写读后感
    { path: '/ydrw/xdhg', name: 'ydrw_xdhg', component: require('./components/ydrw_xdhg.vue')}, 
     // 阅读任务 我的读后感
    { path: '/ydrw/wddhg', name: 'ydrw_wddhg', component: require('./components/ydrw_wddhg.vue')}, 
    // 阅读任务 开始闯关
    { path: '/ydrw/kscg', name: 'ydrw_kscg', component: require('./components/ydrw_kscg.vue')}, 
    // 阅读任务 我的闯关
    { path: '/ydrw/wdcg', name: 'ydrw_wdcg', component: require('./components/ydrw_wdcg.vue')}, 


    //考试提分宝
     { path: '/kstfb', name: 'kstfb', component: require('./components/kstfb.vue')},

    // 书香榜
    { path: '/sxb', name: 'sxb', component: require('./components/sxb.vue')},
     // // 阅读资讯
    { path: '/ydzx', name: 'ydzx', component: require('./components/ydzx.vue')},
    // 阅读资讯 详情
    { path: '/ydzx/xq', name: 'ydzx_xq', component: require('./components/ydzx_xq.vue')},

  
     // // 书库
   // { path: '/', name: 'sc', component: require('./components/sc.vue')},
    { path: '/sc', name: 'sc', component: require('./components/sc.vue')},
    { path: '/sk/xq', name: 'sk_xq', component: require('./components/sk_xq.vue')}, 

    { path: '/sk/sk_search', name: 'sk_search', component: require('./components/sk_search.vue')},
     { path: '/sk/sm_search', name: 'sm_search', component: require('./components/sm_search.vue')},  


    // 个人首页
    { path: '/main', name: 'main', component: require('./components/main.vue')}, 
   
// 消息中心
    { path: '/main/wdxx', name: 'wdxx', component: require('./components/main_wdxx.vue')}, 
  
// 我的分享
    { path: '/main/wdfx', name: 'wdfx', component: require('./components/main_wdfx.vue')}, 
  
// 我的收藏
    { path: '/main/wdsc', name: 'wdsc', component: require('./components/main_wdsc.vue')},
   
// 设置
   { path: '/main/sz', name: 'sz', component: require('./components/main_sz.vue')},  
// 个人信息
    { path: '/main/grxx', name: 'grxx', component: require('./components/main_grxx.vue')}
    
  ]

})


