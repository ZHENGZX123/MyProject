<template>
	<div>
		<!-- 头部 -->
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback"></image>
			<text class="top_name">我的设置</text>
		</div>
		<!-- 修改密码 -->
		<div class="PassWord">
			<text style="font-size:32px;font-weight:900;">修改密码</text>
			<div class="wrapper">
				<text style="font-size:32px;margin-top:10px;" class="Le">登录账号：</text>
				
				<input type="text" name="" class="pot_input" placeholder="登录账号" v-model="loginAccount" />
			</div>
			<div class="wrapper">
				<text style="font-size:32px;margin-top:10px;" class="Le">原密码：</text>
				<input type="password" name="" class="pot_input"  placeholder="原密码" v-model="oldPwd" />
			</div>
			<div class="wrapper">
				<text style="font-size:32px;margin-top:10px;" class="Le" >新密码：</text>
				<input type="password" name="" class="pot_input" placeholder="新密码" v-model="newPwd" />
			</div>
			<div class="wrapper">
				<text style="font-size:32px;margin-top:10px;" class="Le">重复新密码：</text>
				<input type="password" name="" class="pot_input" placeholder="重复新密码" v-model="newPwd1" />
			</div>
			<div class="btn" @click="submit">
				<text class="ipt">确定</text>
			</div>
			
		</div>
		<!-- 清除缓存 -->
		<div class="del">
			<text style="font-size:32px;">清缓存</text>
			<div class="delSize">
				<text style="font-size:32px;">12.5M</text>
				<image src="../static/images/wd_09.png" class="more" ></image>
			</div>
		</div>
		<!-- 关于 -->
		<div class="del">
			<text style="font-size:32px;">关于</text>			
			<image src="../static/images/wd_09.png" class="more" ></image>		
		</div>
		<!-- 退出账号 -->
		<div class="footers">
			<text style="font-size:32px;color:red;">退出账号</text>
		</div>
	</div>
</template>
<script>
	var modal = weex.requireModule('modal')
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				loginAccount:'',
				oldPwd:'',
				newPwd:'',
				newPwd1:'',
			}
		},
		methods: {
			goback(){
				this.$router.go(-1);
			},
			submit() {
				// console.log(self.newPwd.length);
				var self = this;
				console.log(self.oldPwd);
				if (self.newPwd!=self.newPwd1 || self.newPwd == '') {
					modal.alert({
						message: '两次密码不一致，请重试',
						duration: 0.3
					}, function (value) {

					})
				}else if(self.newPwd.length<6){
					modal.alert({
						message: '密码不能小于6位数',
						duration: 0.3
					}, function (value) {
					})
				}else{
					kwz.fetch({
						url : '/app/student/uc/changePwd?loginAccount='+self.loginAccount,
						method:'POST',
						type:'json',
						data:'&oldPwd='+self.oldPwd+'&newPwd='+self.newPwd+'&newPwd1='+self.newPwd,
						success : function(ret){
							console.log(ret);	
						}
					})
					modal.alert({
						message: '密码修改成功',
						duration: 0.3
					}, function (value) {
						self.$router.go(-1);
					})
				}
				
			}
		}
	}
</script>
<style scoped>
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.PassWord{
		width: 750px;
		height: 530px;
		border-bottom-style: solid;
		border-bottom-width: 1px;
		border-bottom-color: #ccc;
		padding: 20px;
		box-sizing: border-box;
	}
	.wrapper{
		flex-direction: row;
		margin-top: 20px;
	}
	.pot_input{
		width: 400px;
		height:70px; 
		font-size: 32px; 
		background-color: #f0f0f0;
		border:none;
		padding-left: 20px;
		border-radius: 3px;

	}
	.del{
		width: 750px;
		height: 100px;
		/* background-color: orange; */
		flex-direction: row;
		justify-content: space-between;
		padding: 20px;
		box-sizing: border-box;
		align-items: center;
		border-bottom-style: solid;
		border-bottom-width: 1px;
		border-bottom-color: #ccc;
	}
	.more{
		width: 20px;
		height: 30px;
		margin-top: 4px;
		margin-left: 20px;
	}
	.delSize{
		flex-direction: row;
	}
	.footers{
		width: 750px;
		height: 110px;
		background-color: #fff;
		position: fixed;
		bottom: 0;
		left: 0;
		border-top-style: solid;
		border-top-width: 1px;
		border-top-color: #ccc;
		align-items: center;
		justify-content: center;
	}
	.btn{
		align-items: center;
		justify-content: center;
		margin-top: 20px;width: 710px;
		height: 70px;background-color:#6fa1e8;
	}
	.ipt{
		/* width: 280px;
		height: 60px; */
		
		align-items: center;
		/* padding-left: 84px; */
		/* padding-top: 10px; */
		color: #fff;
		font-size: 34px;
		
		border-radius: 5px;
	}
	.Le{
		width: 200px;

		/* background-color: orange; */
	}
</style>