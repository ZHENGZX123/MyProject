<template>
	<div>
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback" /> 
			<text class="top_name">我的任务</text>
		</div>
			<div class="tab">
				<div class="tab_li tab_yes" @click="openYdrw"><text class="tab_yes">阅读任务</text></div>
				<div class="tab_li" @click="onpeKstfb" ><text style="font-size: 34px; color: #666;" >考试提分宝</text></div>
			</div>
			<div class="type">
				<div class="type_li" @click="fn" style=" border-right-color: #e6e6e6; border-right-style: solid; border-right-width: 1px; ">
					<text style="font-size: 34px;color: #666; ">{{typeName}}</text>
					<image src="../static/images/ico_17.png" class="type_img" />
				</div>
				<div class="type_li"  @click="show" >
					<text style="font-size: 34px;color: #666; ">{{stateName}}</text>
					<image src="../static/images/ico_17.png" class="type_img" />
				</div>
			</div>
			
		<div class="s_class" v-if="willShow"  style=" left: 0px; height: 260px; ">
			<scroller >
				<div class="s_class_opt"  :style="{ backgroundColor: type.bj, color: type.color}" v-for='type in typeList'  @click="optType(type.id,type.name)" ><text :style="{ backgroundColor: type.bj, color: type.color}"  style=" font-size: 34px; " >{{type.name}}</text></div>
			</scroller>
		</div>
		
		<div class="s_class"  v-if="willShow2" style=" left: 375px; height: 330px; ">
			<scroller>
				<div class="s_class_opt" v-for='state in stateList'  @click="optState(state.id,state.name)" :style="{ backgroundColor: state.bj, color: state.color}"  >
					<text :style="{ backgroundColor: state.bj, color: state.color}"  style=" font-size: 34px; ">{{state.name}}</text>
				</div>
			</scroller>
		</div>
		<scroller>
			<div class="jrrw"> 
					<!-- 任务列表 -->
				<div class="jrrw_list"  :class="['bj' + rw.state]" v-for="rw in rw_list"  @click="openRwxq('/ydrw/ckjh?planId='+rw.planId+'&type='+typeId)">
					<div class="jrrw_info" >
						<text class="rw_title">{{rw.planName}}</text>
						<div class="rw_time">
							<text style="font-size: 26px; color: #808080;">截止：{{rw.endDate}}</text> 
							<text style="font-size: 26px; color: #808080;">{{rw.teaName}}</text>
						</div>
					</div>
					<div class="c_bg" >
						<text class="c_bg_btn" :class="['c_bg_btn' + rw.state]" >{{rw.state | sname}}</text>
						<text class="prompt" v-if="rw.state =='2'">逾期未提交</text>
					</div>
					<image src="../static/images/xs_pic_newR.png" class="newR" v-if="rw.new"></image>
				</div>	
			</div>
			<loading class="loading" @loading="onloading" :display="showLoading">
			      <text class="indicator">加载更多 ...</text>
			</loading>
		</scroller>
	</div>
</template>

<script>
 	const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				page: 1,
				showLoading: 'hide',
				flag: false,	
				willShow:false,
				willShow2:false,
				typeId:'',
				stateId:'',
				typeName:'全部类型',
				stateName:'全部状态',
				stateList:[
					{name:'全部状态',bj:'#d9e8fd',color:'#6fa1e8',id:''},
					{name:'未完成',bj:'',color:'#666',id:0},
					{name:'已过期',bj:'',color:'#666',id:2},
					{name:'已完成',bj:'',color:'#666',id:1}
				],
				typeList:[
					{name:'全部类型',bj:'#d9e8fd',color:'#6fa1e8',id:''},
					{name:'老师任务',bj:'',color:'#666',id:1},
					{name:'专家任务',bj:'',color:'#666',id:2}
				],
				rw_list: [
				/*	{title: '阅读任务：五一读书任务', time: '05-05 23:59',new: true,name:'张老师',state:'0',stateName:'前 往'},
					{title: '阅读任务：元旦读书任务', time: '01-03 23:59',new: false,name:'张老师',state:'1',stateName:'补做'}*/
				],
				loginA:''
			}
		},
		methods: {
	        fn:function(){
	          if(this.willShow==true){
	            this.willShow=false;
	          }else{
	            this.willShow=true
	          }
	        },
	        show:function(){
	          if(this.willShow2==true){
	            this.willShow2=false;
	          }else{
	            this.willShow2=true
	          }
	        },
	        optType:function(id,name){
			    this.typeId=id;
			    this.typeName=name;
	        	this.willShow=false;
			    this.dataLoad();
			    var self = this;
				for(var i in self.typeList){
					self.typeList[i].bj = '';
                    self.typeList[i].color = '#666';
					if(i==id){
						self.typeList[id].bj = '#d9e8fd';
						self.typeList[id].color="#6fa1e8";
					}
				}
	        },
	        optState:function(id,name){
	        	this.stateId=id;
	        	this.stateName=name;
	        	this.willShow2=false;
			    this.dataLoad();
			    var self = this;
				for(var i in self.stateList){
					self.stateList[i].bj = '';
                    self.stateList[i].color = '#666';
					if(i==id){
						self.stateList[id].bj = '#d9e8fd';
						self.stateList[id].color="#6fa1e8";
					}
				}
			 
	        },
	         goback () {
		      //this.$router.go(-1);
		      this.$router.push('/index');
		    },
		    onpeKstfb(){
		      this.$router.push('/kstfb');
		    },
	        openYdrw(){
	        	this.$router.push('/ydrw');
	        },
	        openRwxq(path){
	        	//this.$router.push('/ydrw/ckjh');
	        	this.$router.push(path);
	        },
	        
	        dataLoad(){

	        	if(!this.flag){
					this.rw_list=[];
		    		this.page=1;
				}
			
	        	var self = this;
	        	//this.rw_list=[];
	        	storage.getItem('username',function(e){  //从缓存中取userId
            		self.loginA = e.data;
            		//console.log('-------------'+self.loginA);
            		kwz.fetch({
				    	url : '/app/student/mytask?loginAccount='+self.loginA+'&page='+self.page+'&pageSize=8'+'&type='+self.typeId+'&state='+self.stateId,
				    	method:'POST',
				    	type:'json',
				    	data : '',
				    	success : function(ret){
				    	var datas =ret.data.result;
							//self.rw_list=eval(datas);
							if(ret.data.status==200 ){
				    			for(let i=0;i<datas.length;i++){
				    			self.rw_list.push(datas[i]);
				    			}
				    		}else if(ret.data.status==404){
				    			 modal.toast({ message: '已到底部', duration: 1 })
				    		}
			    			self.flag=false;
			    			self.showLoading = 'hide';
				    	}
				    })
		  		}); 
	        },
	        onloading (event) {
		    	this.page+=1;
		    	this.flag=true;
		       // modal.toast({ message: 'loading', duration: 1 })
		        this.showLoading = 'show';
		        this.dataLoad(); 
		    },
		},
		created : function(){
			this.dataLoad();
		},
		filters:{
			sname:function(v){
				if(v==0){
					return '前 往';
				}else if(v==1){
					return '已完成';
				}else if(v==2){
					return '补 做';
				}
			}
		}
	}
</script>

<style scoped>
	.loading {
  		width: 750px;
    	flex-direction: row;
   	 	align-items: center;
    	justify-content: center;
 	}
  	.indicator {
   		color: #888888;
	    font-size: 42px;
	    padding-top: 20px;
	    padding-bottom: 20px;
	    text-align: center;
 	 }
    .top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.tab{
		height: 70px; 
        margin-top: 19px;
        margin-bottom: 19px;
        margin-right: 60px;
        margin-left: 60px;
		border-width: 2px;
		border-style: solid;
		border-color:#d9e8fd;
		border-radius: 35px; 
		flex-direction: row;
		align-items: center;
		justify-content: center;
	}
	.tab_li{
		flex: 1;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		height: 70px;	
	}
	.tab_yes{
		background-color: #d9e8fd; 
		border-radius: 35px; 
		color: #6fa1e8;
		font-size: 34px;	}

	.type{
		height: 85px; 
		width: 750px;
		flex-direction: row;
		align-items: center; 
		justify-content: center; 
		border-bottom-style: solid;
		border-bottom-color: #e6e6e6;
		border-bottom-width: 1px;
		border-top-style: solid;
		border-top-color: #e6e6e6;
		border-top-width: 1px;	
	}
	.type_li{
		position: relative; 
		flex: 1;
		padding-left: 40px;
		padding-right: 40px; 
		margin-top: 8px;
		flex-direction: row;
		align-items: center; 
		justify-content: space-between; 
	}
	.type_img{
		width: 35px; 
		height: 18px;
	}
	.type_li1{
		position: absolute;
		right: 0;
		z-index: 99; 
		background-color: #fff;  
		width: 50%;
		font-size: 30px;
		height:284px; 
		line-height: 70px;
		flex-direction: column; 
		align-items: center; 
		justify-content: center; 
		text-indent: 0.3px; 
		border-style: solid;
		border-color: #e6e6e6;
		border-width: 1px;
		color: #666; 
	}
	.type_li2{
		height:214px; 
		left: 0;
	}
	.type_ling {
		border-bottom-style: solid;
		border-bottom-color: #e6e6e6;
		border-bottom-width: 1px;
	}
	
	 .s_class{
		position: fixed;
	    z-index: 9999;
	    top: 280px;
		width: 375px;
		padding: 5px;
		height: 270px;
		border-color: #e6e6e6;
		border-style: solid;
		border-width: 1px;
		background-color: #fff;

	}
	.s_class_opt{
		width: 375px;
		height: 80px;
		flex-direction:row;
		align-items: center;
		justify-content: flex-start;
		padding-left: 20px;
		border-bottom-color: #e6e6e6;
		border-bottom-style: solid;
		border-bottom-width: 1px;
	}
	.type_yes{ 
		background-color: #40cc8b;
		color: #fff;	
	 }

	.jrrw{
		width: 750px;
		background-color: #fff;
		padding-top: 30px;
		padding-bottom: 30px;
	}
	.title_img{
		background-color: #70a1e8; 
		margin-right: 0.1px;}
	.jrrw_list{
		overflow: hidden;
		position: relative;
		z-index: 2;
		width: 710px; 
		margin-left: 20px;
		margin-right: 20px;
		background-color:#f1f6fd;
		border-width: 1px;
		border-style: solid;
		border-color:#d9e8fd;
		border-radius: 12px;
		margin-bottom: 20px;
	}
	.newR{
		position: absolute;
		top: -2px;
		right: -2px;
		width: 75px; height:75px;
	}
	.jrrw_info{
		/*float: left;*/
		width: 540px;
		padding-top: 20px;
		padding-bottom: 20px;
		padding-left: 30px;
		padding-right: 30px;
	}
	.rw_title{
		font-size: 34px;
		line-height: 38px;
		color: #666;
	}
	.rw_time{ 
		flex-direction: row;
		align-items: center; 
		justify-content: space-between;
		height: 40px;
		margin-top: 5px;
	}
	.c_bg{
		position: absolute;
		top: 35px;
		right: 0px;
		bottom: 0px;
		width: 150px;
		text-align: center;
	}
	.c_bg_btn{
		text-align: center;
		width: 110px;
		padding-top: 5px;
		padding-bottom:5px;
		font-size: 28px; 
		border-radius: 8px;
		background-color: #70a1e8;
		color: #fff;
		margin-bottom: 10px;
	}
	.prompt{
		position: absolute; 
		bottom: -20px; 
		font-size: 22px; 
		color:#f60; 
		left: 0;
	}
	.bj0{ background-color: #f1f6fd;  }
	
	.bj1{ 
		background-color: #fff; 
		border-width: 1px;
		border-style: solid;
		border-color:#d9e8fd;
	}
	.bj2{ background-color: #fff;  }
	.c_bg_btn2{
		background-color: #fff; 
		color: #70a1e8;
		border-width: 1px;
		border-style: solid;
		border-color:#70a1e8;
	}
	.c_bg_btn1{
		border:#e6e6e6 1px solid; 
		border-width: 1px;
		border-style: solid;
		border-color:#e6e6e6;
		background-color: #fff; 
		color: #999;
	}
</style>