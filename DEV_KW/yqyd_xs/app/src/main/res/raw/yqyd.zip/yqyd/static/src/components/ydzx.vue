<template>
	<div id="ydzx">
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback" />
			<text class="top_name">阅读资讯</text>
		</div>
		<scroller>
			<div class="ydzx_main" >
				<div class="ydzx_list" v-for="ydzx in ydzx_list"  @click="onpeNew('/ydzx/xq?id='+ydzx.id)" >
					<div class="ydzx_l">
						<text class="ydzx_titil" >{{ydzx.title}}</text>
						<text class="ydzx_time">{{ydzx.tags}}</text>
					</div>
					<image :src="ydzx.image" class="ydzx_img" v-if="ydzx.image"></image>
					<text class="ydzx_text">{{ydzx.shortContent}}</text>
					<div class="ydzx_f">
						<text style="color: #4d4d4d; font-size: 34px; ">阅读全文</text>
						<image src="../static/images/xs_pic_more.png" class="ydzx_more"></image>
					</div>
				</div>
			</div>
			<loading class="loading" @loading="onloading" :display="showLoading">
			    <text class="indicator">加载更多 ...</text>
			</loading>
		</scroller>
	</div>
</template>
<script>
	const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				// 阅读资讯列表
				page:1,
				showLoading:'hide',
				ydzx_list: [
					/*{title: '全民阅读不是一句口号', href: '/ydzx/xq', time: '2017-04-10',img:'../static/images/158_150401141239_1.jpeg',text:'有人说，腹有诗书气自华，也有人说，读书改变命运。阅读对人成长的影响是巨大的，一本好书往往能改变人的一生。而一个民族的精神境界，在很大程度上取决于全民族的阅读水平。 '},
					{title: '阅读+对话丨 陈晖：以文学阅读促进儿童全面发展', href: '/ydzx/xq', time: '2017-02-04',img:'../static/images/W020130321296490618267.jpg',text:'在2014年的全国儿童创作出版会议，作协副主席李敬泽先生发表了一个总结的讲话，叫做“儿童文学的再准备”。李敬泽先生指出：儿童文学从来就不仅仅是“文学”，它体现着一个国家、一个民族最深刻、最基本的价值取向和文化关切。要使儿童文学建立在对儿童生活和心灵的可靠知识与精微分析的基础上，使其价值取向和文化关切建立在全社会的充分共识之上。'}*/
				],
			}
		},
		name: 'ydzx',
		created : function(){
		    var self = this
		    kwz.fetch({
		    	url : '/app/information/?page='+self.page+'&pageSize=10',
		    	method:'POST',
		    	type:'json',
		    	success : function(ret){
		    		var data = ret.data.result
		    		if(ret.data.status==200){
			    		for(let i=0;i<data.length;i++){
					    	self.ydzx_list.push(data[i]);
					    }
			    	}else if(ret.data.status==404){
			    		modal.toast({ message: '已到底部', duration: 1 })
			    	}
			    		self.showLoading = 'hide';
		    		// console.log(self.jyzx_list);
		    	}
		    })
		},
		methods: {
			 goback () {
		      this.$router.go(-1);
		    },
		    onpeNew(path){
		      this.$router.push(path);
		    },
		     onloading (event) {
		    	this.page+=1;
		 
		       // modal.toast({ message: '加载更多', duration: 1 })
		        this.showLoading = 'show';
			    var self = this
			    kwz.fetch({
			    	url : '/app/information/?page='+self.page+'&pageSize=10',
			    	method:'POST',
			    	type:'json',
			    	success : function(ret){
			    		var data = ret.data.result
			    		if(ret.data.status==200){
			    			for(let i=0;i<data.length;i++){
					    		self.ydzx_list.push(data[i]);
					    	}
			    		}else if(ret.data.status==404){
			    			 modal.toast({ message: '已到底部', duration: 1 })
			    		}
			    		self.showLoading = 'hide';
			    		
			    	}
			    })
		    }
		}
	}
</script>
<style scoped>

  	.loading {
  		width: 750px;
    	flex-direction: row;
   	 	align-items: center;
    	justify-content: center;
 	}
  	.indicator {
   		color: #888888;
	    font-size: 42px;
	    padding-top: 20px;
	    padding-bottom: 20px;
	    text-align: center;
 	 }
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.ydzx_main{
		width: 750px; 
		background-color: #f0f0f0;
		margin-bottom: 30px;
	}
	.ydzx_list{
		margin-left:20px;
		margin-right:20px;
		margin-top:30px;
		border-style: solid;
		border-width: 1px;
		border-color: #e7e7e7;
		border-style: solid;
		background-color: #fff;
	}
	.ydzx_l{
		padding: 20px;
	}
	.ydzx_img{
		width: 630px;
		height: 320px;
		margin-left:30px;
		margin-right:30px;
		margin-top:3px;
		margin-bottom:3px;
	}
	.ydzx_text{
		font-size: 30px;
		color: #999;
		padding-left:30px;
		padding-right:30px;
		padding-bottom: 10px; 
		padding-top: 10px;
		line-height:45px; 
		background-color: #fff;
		overflow : hidden;
		text-overflow: ellipsis;
		lines:2;
	}
	.ydzx_more{
		width: 18px;
		height: 30px;
	}
	.ydzx_titil{
		color:#333; 
		font-size:36px; 
		line-height: 60px; 
		overflow:hidden; 
		text-overflow:ellipsis; 
		white-space:nowrap;
	}
	.ydzx_time{
		color:#b7b7b7; 
		font-size: 34px;
	}
	.ydzx_f{
		flex-direction: row;
		align-items: center;
		justify-content: space-between;
		height: 85px; 
		
		margin-left:20px;
		margin-right:20px;
	    border-top-width: 1px;
		border-color: #e7e7e7;
		border-style: solid;
	}
</style>