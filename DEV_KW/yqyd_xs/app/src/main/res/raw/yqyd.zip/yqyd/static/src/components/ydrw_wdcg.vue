<template>
	<div>
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback"  @click="goback" />
			<text class="top_name">小巴掌故事</text>
		</div>
		<div class="state"><text class="count">答对7道，答错3道，正确率：70%</text></div>
		<scroller>
			<div class="content">
				<div v-for="q in q_list">
					<div class="question"><text style=" font-size: 36px; color: #666; ">{{q.id}}.{{q.title}}(&nbsp;&nbsp;&nbsp;&nbsp;)</text></div>
					<div v-for="a in q.answer" class="answer" >
						<text style=" font-size: 34px; color: #666; " @click='last(q.ans,a.ans)'>{{a.ans}}、{{a.option}}</text>
					</div>
					<div class="list" >
						<div class="t_q" @click="show">
							<div class="t_q_btn"><text style="font-size:36px; color: #fff; ">解析</text><image src="../static/images/pic_jx.png" style=" width: 29px; height: 36px; " ></image></div>
						</div>
						<div class="j_cnt">
							<text class="ans">正确答案是{{q.ans}}，你的答案是{{q.answer.ans}}<text v-if='q.answer.ans'>回答错误</text><text v-if='!q.answer.ans'>回答正确</text></text>
							<text class="tips">解析</text>
							<text class="contents">{{q.cnt}}</text>
							<div @click="hidden">
								<text style=" font-size: 34px; ">收起</text>
							</div>
						</div>
					</div>
				</div>
			</div>
		</scroller>
		<div class="footer">
			<!--<router-link to='/kstfb/tjh'>-->
			<text style="font-size: 39px; color: #fff;">重新闯关</text>
			<!--</router-link>-->
		</div>
	</div>
</template>


<script>
	export default {
		data(){
			return {
				q_list: [
					{id: 1,title: '请问下面哪一项是正确',ans:'A',cnt:'问题解析……',
						answer:[
							{option: '选项一',ans:'A'},
							{option: '选项二',ans:'B'},
							{option: '选项三',ans:'C'},
							{option: '选项四',ans:'D'}
						]
					},
					{id: 2,title: '1954年重大事件',ans:'B',
						answer:[
							{option: '123',ans:'A'},
							{option: '321',ans:'B'},
							{option: '131',ans:'C'},
							{option: '212',ans:'D'}
						]
					},
					{id: 3,title: '秦国哪一年建立',ans:'D',
						answer:[
							{option: '111',ans:'A'},
							{option: '222',ans:'B'},
							{option: '333',ans:'C'},
							{option: '000',ans:'D'}
						]
					},
				]
				
			}
		},
		methods: {
			last: function(i,x,el){
				if(i==x){
						
				}else{
						
				}
			},
		    goback () {
		       this.$router.go(-1);
		    }

		},
		directives: {
			
			/*// 解析按钮自定义点击事件指令
			click: {
				inserted: function(el){
					el.onclick=function(){
						// 获取解析内容
						var nextNode=this.parentNode.parentNode.getElementsByTagName('div')[1];
						// 显示解析内容
						nextNode.style.display='block';
					}
				},
			
			},
			// 收起解析
			hidden: {
				inserted: function(el){
					// el.
					el.onclick=function(){
						this.parentNode.parentNode.style.display='none';
					}
				}
			}*/
		}
	}
</script>

<style scoped>

	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.content{
		width: 750px;
		padding-right: 25px;
		padding-left: 25px;
		padding-top: 30px;
		background-color: #fff;
		padding-bottom: 120px;
	}

	.state{
		flex-direction: row;
		align-items: center;
		justify-content: center;
		height:88px;
		border-bottom-width: 1px;
		border-bottom-color: #e7e7e7;
		border-bottom-style: solid;
	}
	.count{
		font-size: 34px;
		color: #666;
	}
	.question{
		flex-direction: row;
		align-items: center;
		width: 750px;
		height: 88px;
		justify-content: left;
		font-size: 36px;
		color: #333333;
	}
	.answer{
		margin-top: 25px;
		font-size: 34px;
		color: #808080;
		flex-direction: row;
		justify-content: left;
		align-items: center;
		padding: 20px;
		background-color: #fafafa;
		border-radius: 30px;
	}
	.yes{
		background-color: #40cc8b;
		color: #fff;
	}
	.no{
		background-color: #f66c6c;
		color: #fff;
		font-size:34px;
	}
	.footer{
		position: fixed;
		bottom: 0px;
		left: 0px;
		width: 750px;
		height: 100px;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		background-color: #6fa1e8;
	}

	.list{
		margin-bottom: 20px;
		background-color: #fff;
	}
	.t_q{
		width: 750px;
		height: 140px;
		flex-direction: row;
		align-items: center;
		justify-content:flex-end;
		padding: 30px;
		border-bottom-width: 1px;
		border-right-style: solid;
		border-bottom-color: #e7e7e7;
	}
	.t_q_btn{
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		width: 200px;
		height: 80px;
		padding-right: 30px;
		padding-left: 30px;
		border-radius: 50px;
		margin-right: 40px;
		background-color: #70a1e8;
	}
	.j_cnt{
		display: none;
		padding-top: 26px;
		padding-bottom: 26px;
		padding-left: 30px;
		padding-right: 30px;
		width:750px;
		border-bottom-color: #e6e6e6;
		border-bottom-style: solid;
		border-bottom-width: 1px;
	}
	.ans{
		font-size: 33px;
		color: #808080;
	}
	.ans span{
		color: #ff6060;
	}

	.tips{
		font-size: 33px;
		color: #79a8ec;
		margin-top: 40px;
		font-size: 40px;
	}
	.contents{
		font-size: 33px;
		color: #343434;
		line-height: 50px;
		margin-top: 25px;
	}
	.j_cnt div{
		margin-top: 100px;
		width: 100%;
		text-align: center;
	}
	.j_cnt a{
		font-size: 35px;
		color: #79a8ec;
	}

</style>
