<template>
	<div>
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback"  @click="goback" />
			<text class="top_name">{{bName}}</text>
		</div>
		<div class="state">
			<text class="count">{{index}}/{{length}}</text>
		</div>

		<div class="content">
			<div>
				<div class="question"><text style=" font-size: 36px; color: #666;">{{index}}.{{tm.qname}}(&nbsp;&nbsp;&nbsp;&nbsp;)</text></div>
				<div v-for="(a, i) in an_list" class="answer" >
					<div class="a_list" @click='_chose(i, a.rightOption, a.answerOption)' :class="['a_l_'+a.flag]">
						<text class='a_c'  :class="['a_t_'+a.flag]">{{a.answerOption}}、</text>
						<text v-if='!pic_flag' class='a_t'  :class="['a_t_'+a.flag]">{{a.content}}</text>
						<image v-if='pic_flag' class='pic_t' :src='a.picUrl'></image>
					</div>
				</div>
			</div>
			<div class="list" v-if='a_flag'>
				<div class="j_cnt">
					<text class="ans">正确答案是{{c_ans}}</text>
					<text class="tips">解析</text>
					<text class="contents"></text>
				</div>
			</div>
			<div class="next" v-if='c_flag' @click='_next'>
				<text class='n_t'>下一题</text>
			</div>
			<div class="next" v-if='e_flag' @click='_end'>
				<text class='n_t'>完成</text>
			</div>
		</div>
	</div>
</template>

<script>
	var modal=weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				message: '',
				win: false,
				flag: false,
				// 题目
				tm: {},
				// 答案
				an_list: [],
				// 当前第几题
				index: 1,
				// 已选择
				c_flag: false,
				// 正确答案
				c_ans: '',
				// 答案是否正确
				a_flag: false,
				// 结束
				e_flag: false,
				// 题目数量
				length: 0,
				// 选项是否是图片
				pic_flag: false,
				// 书名
				bName: '',
				// 答题正确数量
				yCount: 0,
				// 答题错误数量
				nCount: 0
			}
		},
		created: function(){
			this.bName=this.$route.query.bname;
			// 初始化题目
			var self=this;
			kwz.fetch({
			    	url : '/app/student/question/'+self.$route.query.bid+'?index='+self.index+'&loginAccount=10099521',
			    	method:'POST',
			    	type:'json',
			    	//data:'loginAccount=12&token=123123&id=1',
			    	success : function(ret){
			    		if(ret.data.status==200){
			    			self.tm = ret.data.result.question;
			    			self.an_list = ret.data.result.answer;
			    			self.length= ret.data.result.total;
			    			for(let i=0;i<self.an_list.length;i++){
			    				if(self.an_list[i].rightOption==1){
			    					self.c_ans=self.an_list[i].answerOption;
			    					break;
			    				}
			    			}
			    			if(ret.data.result.picAnswer==1){
			    				self.pic_flag=true;
			    			}else{
			    				self.pic_flag=false;
			    			}
			    		}
			    	}
			})
			// var self=this;
			// document.addEventListener("touchmove",function(event){
			// 	if(self.flag){
			// 		event.preventDefault();
			// 		document.documentElement.style.overflow='hidden';
			// 	};
			// },{ passive: false });
		},
		methods: {
			_close: function(){
				this.flag=false;
			},
			_show: function(){
				this.flag=true;
			},
			 goback () {
		      		 this.$router.go(-1);
		   	 },
		   	 // 选择
		   	 _chose: function(i, flag, option){
				var self=this;
				kwz.fetch({
				    	url : 'app/student/answer/record?bookId='+self.$route.query.bid+'?index='+self.index+'&loginAccount=10099521&planId='+self.$route.query.pid+'&questionId='+self.tm.questionId+'&chooseOption='+option+'&right='+flag,
				    	method:'POST',
				    	type:'json',
				    	//data:'loginAccount=12&token=123123&id=1',
				    	success : function(ret){
				    		if(ret.data.status==200){
				    			// console.log(1);
				    		}
				    	}
				})
		   	 	if(this.c_flag){
		   	 		return false;
		   	 	}else{
		   	 		if(flag==1){
		   	 			this.yCount+=1;
		   	 			this.an_list[i].flag='y';
		   	 		}else{
		   	 			this.nCount+=1;
		   	 			this.an_list[i].flag='n';
		   	 			this.a_flag=true;
		   	 		}
			   	 	if(this.index==this.length){
			   	 		this.e_flag=true;
			   	 		this.c_flag=false;
			   	 	}else{
			   	 		this.c_flag=true;
			   	 	}
			   	 }
		   	 },
		   	 // 下一题
		   	 _next: function(){
				var self=this;
		   	 	if(this.index!=this.length){
			   	 	// 关闭解析
					this.a_flag=false;
					// 隐藏下一题
				   	this.c_flag=false;
			   	 	this.index+=1;
			   	 	this.an_list=[];
			   	 	this.tm={};
					kwz.fetch({
					    	url : '/app/student/question/'+self.$route.query.bid+'?index='+self.index+'&loginAccount=10099521',
					    	method:'POST',
					    	type:'json',
					    	//data:'loginAccount=12&token=123123&id=1',
					    	success : function(ret){
					    		if(ret.data.status==200){
					    			self.tm = ret.data.result.question;
					    			self.an_list = ret.data.result.answer;
					    			self.length= ret.data.result.total;
					    			for(let i=0;i<self.an_list.length;i++){
					    				if(self.an_list[i].rightOption==1){
					    					self.c_ans=self.an_list[i].answerOption;
					    					break;
					    				}
					    			}
					    		}
					    	}
					})
				}
		   	 },
		   	 _end: function(){;
		   	 	this.$router.push('/ydrw/cgjg?zq='+this.yCount+'&cw='+this.nCount+'&zql='+parseInt(this.yCount/this.length*100));
		   	 }
		}
	}
</script>

<style scoped>
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.state{
		border-bottom: 1rem solid #e7e7e7;
		background-color: #fff;
		width: 750px;
		padding: 28px;
		font-size: 32px;
	}
	.section{
		color: #79a8ec;
	}
	.count{
		flex: 1;
		color: #9c9c9c;
		text-align: center;
	}
	.count span{
		color: #79a8ec;
	}
	.t_title{
		padding: 38rem 27rem 0px;
		overflow: hidden;
		background-color: #fff;
	}
	.content{
		width: 100%;
		padding: 38rem 27px;
		background-color: #fff;
	}
	.content:nth-child(n+7){
		margin-top: 20px;
		border-top: 1rem solid #e7e7e7;
	}
	.content:last-child{
		margin-bottom: 1px;
	}
	.title{
		font-size:40px;
		color: #333333;
		float: left;
	}
	.diff{
		float: left;
		line-height: 36px;
		font-size: 32px;
		color: #999999;
		margin-left: 32px;
		vertical-align: text-bottom;
	}
	.diff span{
		display: inline-block;
		width: 29px;
		height: 29px;
		/*background-image: url('../../static/images/xs_ico_25.png');
		background-size: 100% 100%;
		vertical-align: middle;*/
	}
	.topic{
		width: 100%;
		font-size: 35px;
		color: #333333;
	}
	.content a{
		margin-top: 25px;
		display: block;
		font-size: 33px;
		color: #808080;
		line-height: 50px;
	}
	button.tj{
		position: fixed;
		bottom: 0px;
		left: 0px;
		z-index: 9;
		border: 0px;
		width: 100%;
		height: 100px;
		background-color: #79a8ec;
		line-height: 100px;
		text-align: center;
		color: #fff;
		font-size: 35px;
	}
	.jg{
		position: absolute;
		top: 0px;
		bottom: 0px;
		z-index: 9999999;
		width: 100%;
		background-color: rgba(0,0,0,0.8);
	}
	.wins,.loser{
		display: none;
		position: absolute;
		top: 50%;
		left: 50%;
		z-index: 999;
		margin-top: -27px;
		margin-left: -32px;
		width: 645px;
		height: 540px;
		background-color: #fff;
		border-radius: 35px;
	}
	.img_t{
		display: block;
		position: absolute;
		left: 50%;
		margin-left: -27px;
		top: -11px;
		width: 541px;
		height: 231px;
	}
	.jb,.l_jb{
		display: block;
		width: 80px;
		margin: 0 auto;
		margin-top: 60px;
		margin-bottom: 60px;
	}
	.wins p,.l_p{
		width: 100%;
		font-size: 35px;
		color: #999999;
		text-align: center;
	}
	.wins p span{
		color: #40cc8b;
	}
	.wins a,.loser a{
		display: block;
		margin: 0 auto;
		margin-top: 70px;
		width: 33px;
		height: 100px;
		background-color: #40cc8b;
		color: #fff;
		font-size: 40px;
		text-align: center;
		line-height: 100px;
		border-radius: 200px;
	}
	.bj{
		display: none;
		width: 100%;
		position: absolute;
		top: 0px;
		left: 0px;
		z-index: 9;
	}
	.l_tle{
		width: 100%;
		font-size: 50px;
		color: #869ab5;
		font-weight: 700;
		text-align: center;
		margin-top: 50px;
	}
	.l_jb{
		margin-top: 30px;
	}
	.loser p span{
		color: #f66c6c;
	}
	.loser a{
		background-color: #f66c6c;
	}
	.show{
		display: block;
	}

	.content{
		width: 750px;
		padding-right: 25px;
		padding-left: 25px;
		padding-top: 30px;
		background-color: #fff;
		padding-bottom: 120px;
	}

	.state{
		flex-direction: row;
		align-items: center;
		justify-content: center;
		height:88px;
		border-bottom-width: 1px;
		border-bottom-color: #e7e7e7;
		border-bottom-style: solid;
	}
	.count{
		font-size: 34px;
		color: #666;
	}
	.question{
		flex-direction: row;
		align-items: center;
		flex: 1;
		justify-content: left;
		font-size: 36px;
		color: #333333;
	}
	.answer{
		margin-top: 25px;
		flex-direction: column;
	}
	.a_list{
		flex: 1;
		flex-direction: row;
		justify-content: left;
		align-items: center;
		/*padding: 20px;*/
		background-color: #fafafa;
		border-radius: 30px;
		border-width: 2px;
		border-style: solid;
		border-color: #555555;
		padding: 20px;
	}
	.a_c{
		flex: 0.4;
		color: #808080;
		font-size: 34px;
	}
	.a_t{
		flex: 3;
		color: #808080;
		font-size: 34px;
		/*border-radius: 30px;*/
	}
	.pic_t{
		flex: 1;
		width: 200px;
		height: 200px;
	}
	.a_l_y{
		background-color: #40cc8b;
	}
	.a_l_n{
		background-color: #f66c6c;
	}
	.a_t_y{
		color: #fff;
		font-size:34px;
	}
	.a_t_n{
		color: #fff;
		font-size:34px;
	}
	.footer{
		position: fixed;
		bottom: 0px;
		left: 0px;
		width: 750px;
		height: 100px;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		background-color: #6fa1e8;
	}

	.list{
		flex: 1;
		margin-bottom: 20px;
		background-color: #fff;
		border-top-width: 1px;
		border-top-style: solid;
		border-top-color: #e7e7e7;
		margin-top: 20px;
	}
	.t_q{
		width: 750px;
		height: 140px;
		flex-direction: row;
		align-items: center;
		justify-content:flex-end;
		padding: 30px;
		border-bottom-width: 1px;
		border-right-style: solid;
		border-bottom-color: #e7e7e7;
	}
	.t_q_btn{
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		width: 200px;
		height: 80px;
		padding-right: 30px;
		padding-left: 30px;
		border-radius: 50px;
		margin-right: 40px;
		background-color: #70a1e8;
	}
	.j_cnt{
		padding-top: 26px;
		padding-bottom: 26px;
		padding-left: 30px;
		padding-right: 30px;
		flex: 1;
		border-bottom-color: #e6e6e6;
		border-bottom-style: solid;
		border-bottom-width: 1px;
	}
	.ans{
		font-size: 33px;
		color: #808080;
	}
	.ans span{
		color: #ff6060;
	}

	.tips{
		font-size: 33px;
		color: #79a8ec;
		margin-top: 40px;
		font-size: 40px;
	}
	.contents{
		font-size: 33px;
		color: #343434;
		line-height: 50px;
		margin-top: 25px;
	}
	.j_cnt div{
		margin-top: 100px;
		width: 100%;
		text-align: center;
	}
	.j_cnt a{
		font-size: 35px;
		color: #79a8ec;
	}
	.next{
		flex: 1;
		margin: 20px;
		margin-top: 50px;
		border-radius: 20px;
		height: 100px;
		background-color: #6fa1e8;
		justify-content: center;
		align-items: center;
	}
	.n_t{
		color: #fff;
		font-size: 35px;
	}
</style>