<template>
	<div style=" background-color: #fafafa; ">
	<!-- 	<div class="top">
			<div class="topMain">
				<image src="../static/images/ico_look.png" class="look" />
				
					<input type="text" name=""   @input="keyUps($event)"  class="pot_input" placeholder="请输入书籍名称" />
			</div>
			<text class="goback_r"  @click="goback">取消</text>
		</div> -->
		<myedittext :content='title' @cancel='cancel' @search='search' style='height:100px;width: 750px;'></myedittext>
		<!-- 书详情内容 -->
		
		<div class="main">
			<div class="hot_list" >
				<image src="../static/images/pic_hot.png" class="hot"/>
				<text style="font-size: 32px;">热门搜索</text>
			</div>
			<div class="hot_list" v-for="(ssList,index) in  searchList"  @click="selectes(ssList.word)">
				<text class="hot orange">{{index+1}}</text>
				<text style="font-size: 32px;">{{ssList.word}}</text>
			</div>
		</div>
	</div>
</template>
<script>
  	const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				ss:'',
				searchList: 
					{/*src: '../static/images/book02.png', btime: '2017-01-01', etime: '2017-01-02', bname: '飞来的伤心梅', bath: '张琴声', bpre: '北京邮电',isbn:'9787547705063'*/},
				title : ''
			}
		},

		methods: {
			/* goback () {
		     
		    },*/
		    selectes:function(e){
		    	this.title=e;
		    },
		    cancel(e){
		    	this.$router.go(-1);
		    },
		    search(e){
				//storage.setItem('title',e.content);
				/*modal.toast({
		    		message:e.content
		    	});*/
				this.$router.push('/sk/sm_search?title='+e.content);
		    	/*modal.toast({
		    		message:e.content
		    	});*/
		    },
		   /* openSs(){
		    	
		    },
		    keyUps(event){

		    	alert(0)
		    }*/
		},
		created: function(){
			var self = this;
	           console.log(self.$route.query.type);
            	  kwz.fetch({
			    	url : '/app/book/hot',
			    	method:'POST',
			    	type:'json',
			    	//data:'loginAccount=12&token=123123&id=1',
			    	success : function(ret){
			    		var datas = ret.data.result;
			    		self.searchList=eval(datas);
			    		console.log(self.searchList);
			    	}
			 })
            // window.addEventListener('keyup', this.keyUp(),false)
		}/*,
		beforeDestroy(){
			// window.removeEventListener('keyup', this.keyUp())	
		}*/
		
	}
</script>
<style scoped>
	.top{
		width: 750px;
		height: 98px;
		background-color: #fff;
		border-bottom-width: 1px;
		border-style: solid;
		border-color: #e7e7e7;
	}
	.topMain{
		flex-direction: row;
		align-items: center;
		font-size: 36px;
		line-height: 88px;
		width:600px;
		background-color: #f0f0f0;
		border-radius: 8px; 
		margin-bottom: 12px;
		margin-top: 12px;
		margin-left: 20px; 
		margin-right: 20px;

	}
	.pot_input{
		width: 490px;
		height:70px; 
		font-size: 32px; 
		background-color: #f0f0f0;
		border:none;
	}
	.look{
		width: 48px; 
		height: 48px; 
		margin-left: 20px; 
		margin-right: 20px;
	}
	.main{
		background-color: #fff; 
		padding-bottom: 30px;
	}
	.goback_r{
		position: absolute;
		top: 30px;
		right: 25px;
		width: 100px;
		height: 37px; 
		text-align: center;
		color: #666;
		font-size: 34px;
	}
	
	.hot_list{
		flex-direction: row;
		justify-content: left; 
		align-items: center;
		border-bottom-style: solid;
		border-bottom-color: #e7e7e7;
		border-bottom-width: 1px;
		height: 88px;
		margin-left: 30px;
		color: #666;
	}
	.hot{
		width: 40px;
		height: 40px;
		margin-right: 20px;
		font-size: 30px;
	}
	.orange{
		color:#f60;
	}
	
</style>