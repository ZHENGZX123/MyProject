<template>
	<div>
		<div class="footer">
			 <div class="f_list" @click="tab" >
					<image src="../static/images/xs_pic_sy.png" class="footer_img" />
					<text style=" margin-top: 9px; color:#70a1e8;">首 页</text>
			</div>
			 <div class="f_list" @click="tab1">
					<image src="../static/images/pic_sc01.png" class="footer_img"/>
					<text style=" margin-top: 9px; color: #666;">书 库</text>
			</div>
			 <div class="f_list" @click="tab2" >
					<image src="../static/images/pic_w01.png" class="footer_img" /></image>
					<text style=" margin-top: 9px; color: #666;">我 的</text>
			</div>
		</div>
	</div>
</template>
<style scoped>
	.footer{
		width: 750px;
		height: 110px;
		border-style: solid;
		border-color: #e7e7e7;
		border-top-width: 1px;
		position: fixed;
		bottom: 0px;
		left: 0px;
		z-index: 999;
		flex-direction: row;
		align-items: center; 
		justify-content: center;
		background-color: #fff;
	}
	.f_list{
		flex: 1;
		flex-direction: column; 
		align-items: center; 
		justify-content: center;
	}
	.footer_img{
		margin-top: 12px;
		width: 44px;
		height: 44px;
	}
</style>
<script>
	export default {
		data(){
			return {
				/*src: [
					{href: '/index', value: 'index', title: '首 页',img: '../static/images/xs_pic_sy.png',},
					{href: '/sc', value: 'sc', title: '书 库',img: '../static/images/pic_sc01.png',},
					{href: 'lt', value: 'lt', title: '阅读圈'},
					{href: '/main', value: 'main', title: '我 的',img: '../static/images/pic_w01.png',}
				],
				flag: 0*/
			}
		},
		/*computed: {
			bg: function(){
				if(this.show==0){
					return '/index'
				}
				if(this.show==1){
					return '/sc'
				}
				if(this.show==2){
					return '/lt'
				}
				if(this.show==2){
					return '/main'
				}
			}
		},
		props: ['show']
		,*/
		 methods: {
     		tab () {
        		this.$router.push('/index');
      		},
      		tab1 () {
        		this.$router.push('/sc');
      		},
      		tab2 () {
        		this.$router.push('/main');
      		},
    
	    }
	}
</script>