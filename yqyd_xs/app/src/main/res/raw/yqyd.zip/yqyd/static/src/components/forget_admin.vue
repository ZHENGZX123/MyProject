<template>
	<div  style=" background-color: #fafafa; font-family: 黑体; ">
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback" />
			<text class="top_name">找回账号</text>
		</div>
	
		<div style=" width: 750px; padding:25px;">
			<div style=" width: 700px; height: 88px; flex-direction: row;  align-items: center; ">
			<text style=" font-size: 34px; color: #666; " >请真实准确地填写信息，用于找回密码。</text></div>
			<div class="inputK">
				<input type="text" v-model="username" placeholder="输入学生姓名" class="input" />
			</div>
			<div style=" width: 700px; height: 88px; flex-direction: row;  align-items: center; "><text style=" font-size: 34px; color: #666; " >丨我的学校：</text></div>
			<div class="nav1"  >
				<div class="nav1_li"  @click="prov">
					<text style="font-size: 32px; color: #666;">{{allProv}}</text>
					<image src="../static/images/ico_17.png" style=" width:35px; height: 18px; " ></image>
				</div>
				<div  class="nav1_li"  @click="city">
					<text style="font-size: 32px; color: #666; ">{{allCity}}</text>
					<image src="../static/images/ico_17.png" style=" width:35px; height: 18px;  " ></image>
				</div>
			</div>
			<div class="nav1"  >
				<div class="nav1_li"  @click="area">
					<text style="font-size: 32px; color: #666;">{{allArea}}</text>
					<image src="../static/images/ico_17.png" style=" width:35px; height: 18px; " ></image>
				</div>
				<div  class="nav1_li"  @click="school">
					<text style="font-size: 32px; color: #666; ">{{allSchool}}</text>
					<image src="../static/images/ico_17.png" style=" width:35px; height: 18px;  " ></image>
				</div>
			
			</div>
			<div class="s_class" v-if="willShow"  style=" left: 50px; ">
				<scroller >
					<div class="s_class_opt"  @click="optProv('','选择省份', $event)" >
						<text style=" font-size: 34px;" >选择省份</text>
					</div>
					<div class="s_class_opt" v-for='prov in provList'  @click="optProv(prov.id,prov.name,$event)" >
						<text style=" font-size: 34px;" >{{prov.name}}</text>
					</div>
				</scroller>
			</div>
			<div class="s_class" v-if="willShow1"  style=" left: 395px; ">
				<scroller >
					<div class="s_class_opt"  @click="optCity('','选择城市', $event)" >
						<text style=" font-size: 34px; " >选择城市</text>
					</div>
					<div class="s_class_opt" v-for='city in cityList'  @click="optCity(city.id,city.name,$event)" ><text style=" font-size: 34px; " >{{city.name}}</text></div>
				</scroller>
			</div>
			<div class="s_class" v-if="willShow2" style=" left: 50px; top: 675px; ">
				<scroller>
					<div class="s_class_opt" @click="optArea('', '选择片区', $event)" >
						<text style=" font-size: 34px; ">选择片区</text>
					</div>
					<div class="s_class_opt" v-for='area in areaList'  @click="optArea(area.id,area.name,$event)" >
						<text style=" font-size: 34px; ">{{area.name}}</text>
					</div>
				</scroller>
			</div>
			<div class="s_class" v-if="willShow3" style=" left: 395px; top: 670px; ">
				<scroller>
					<div class="s_class_opt" @click="optSchool('', '选择学校', $event)" >
						<text style=" font-size: 34px; ">选择学校</text>
					</div>
					<div class="s_class_opt" v-for='school in schoolList'  @click="optSchool(school.id,school.name,$event)" >
						<text style=" font-size: 34px; ">{{school.name}}</text>
					</div>
				</scroller>
			</div>
		
			<div class="" style=" width: 700px; height: 88px; flex-direction: row;  align-items: center; "><text style=" font-size: 34px; color: #666; " >丨我的班级：</text></div>
			<div class="nav1"  >
				<div class="nav1_li" @click="grade">
					<text style="font-size: 32px; color: #666;">{{allGrade}}</text>
					<image src="../static/images/ico_17.png" style=" width:35px; height: 18px; " ></image>
				</div>
				<div  class="nav1_li" @click="classes">
					<text style="font-size: 32px; color: #666; ">{{allClass}}</text>
					<image src="../static/images/ico_17.png" style=" width:35px; height: 18px;" ></image>
				</div>
			</div>

			<div class="s_class" v-if="willShow4" style=" left: 50px;top: 870px; ">
				<scroller>
					<div class="s_class_opt" @click="optGrade('', '选择年级', $event)" >
						<text style=" font-size: 34px; ">选择年级</text>
					</div>
					<div class="s_class_opt" v-for='grade in gradeList'  @click="optGrade(grade.id,grade.name,$event)" >
						<text style=" font-size: 34px; ">{{grade.name}}</text>
					</div>
				</scroller>
			</div>
			<div class="s_class" v-if="willShow5" style="left: 395px; top: 870px;">
				<scroller>
					<div class="s_class_opt" @click="optClass('', '选择班级', $event)" >
						<text style=" font-size: 34px; ">选择班级</text>
					</div>
					<div class="s_class_opt" v-for='classL in classList'  @click="optClass(classL.id,classL.name,$event)" >
						<text style=" font-size: 34px; ">{{classL.name}}</text>
					</div>
				</scroller>
			</div>

           <text @click="openIndex" class="btn" >查    询</text>

		</div>

	</div>
</template>


<script>
    const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');

    var event = weex.requireModule('@weex-module/SJevent') 

	import kwz from '../../static/js/Utils.js'

	
	export default {
		data(){
			return {
				// 活动列表
				allProv:'选择省份',
				allCity:'选择城市',
				allArea:'选择片区',
				allSchool:'选择学校',
				allGrade:'选择年级',
				allClass:'选择班级',
				provId:'',
				cityId:'',
				areaId:'',
				schoolId:'',
				gradeId:'',
				classId:'',
				willShow:false,
				willShow1:false,
				willShow2:false,
				willShow3:false,
				willShow4:false,
				willShow5:false,
				provList: [{name:'广东省'}],
            	cityList: [{name:'深圳'},{name:'广州'}],
            	areaList: [{name:'南山区'},{name:'罗湖区'},{name:'福田区'},{name:'龙岗区'},{name:'龙华区'}],
            	schoolList: [{name:'深圳南山外国语小学'},{name:'深圳小学'}],
            	gradeList: [{name:'一年级'},{name:'二年级'},{name:'三年级'},{name:'四年级'},{name:'五年级'}],
            	classList: [{name:'一年一班'},{name:'一年二班'},{name:'一年三班'},{name:'一年四班'}],

				ydzxXq: {}
			}
		},
		methods: {
			prov:function(id,name){
				if(this.willShow==true){
			        this.willShow=false;
			    }else{
			        this.willShow=true;
			    }

			 /*   event.selectRegion(,function(res){

			    })

*/
			  

			},
			city:function(id,name){
				if(this.willShow1==true){
			        this.willShow1=false;
			    }else{
			        this.willShow1=true;
			    }
			},
			area:function(id,name){
				if(this.willShow2==true){
			        this.willShow2=false;
			    }else{
			        this.willShow2=true;
			    }
			},
			school:function(id,name){
				if(this.willShow3==true){
			        this.willShow3=false;
			    }else{
			        this.willShow3=true;
			    }
			},
			grade: function(id,name){
			    if(this.willShow4==true){
			        this.willShow4=false;
			    }else{
			        this.willShow4=true;
			    }
			    /*var self = this
			    kwz.fetch({
			    	url : '/app/book/grade',
			    	method:'POST',
			    	type:'json',
			    	//data : 'token=112&module=1&grade=1&type=1',
			    	success : function(ret){
			    		var grades = ret.data.grade
			    		self.grade=eval(grades);
			    		
			    	}
			    })*/
	       	},
	       	classes:function(id,name){
				if(this.willShow5==true){
			        this.willShow5=false;
			    }else{
			        this.willShow5=true;
			    }
			},
			optProv:function(id,name){
				this.provId=id;
			    this.allProv=name;
	        	this.willShow=false;
			},
			optCity:function(id,name){
				this.cityId=id;
			    this.allCity=name;
	        	this.willShow1=false;
			},

			optArea:function(id,name){
				this.areaId=id;
			    this.allArea=name;
	        	this.willShow2=false;
			},
			optSchool:function(id,name){
				this.schoolId=id;
			    this.allSchool=name;
	        	this.willShow3=false;
			},
	        optGrade:function(id,name){
			    this.gradeId=id;
			    this.allGrade=name;
	        	this.willShow4=false;
	        },
	        optClass:function(id,name){
	        	this.classId=id;
	        	this.allClass=name;
	        	this.willShow5=false;
	        },
		    goback: function () {
		        this.$router.go(-1);
		    }
		},
		created: function(){

			 //this.light(0,2);
			 var self = this;
		/*	console.log(self.$route.query.id);
            	  kwz.fetch({
			    	url : '/app/information/'+self.$route.query.id,
			    	method:'POST',
			    	type:'json',
			    	//data:'loginAccount=12&token=123123&id=1',
			    	success : function(ret){
			    		var datas = ret.data.result;
			    		self.ydzxXq=eval(datas);
			    	
			    	}
			  })
     	
		*/


		}
	}
</script>
<style scoped >
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		width: 550px;
		margin-left:100px;
		margin-right:100px;
		text-overflow: ellipsis;
		lines:1;
		font-size: 36px;
		color: #fff;
		text-align: center;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}

    .inputK{
		width: 650px; 
		height:100px; 
		margin: 25px; 
		color: #fff; 
		border-radius: 8px;  
		border-color: #6fa1e8;
		border-style: solid;
		border-width: 1px; 
	}
	.input{
		width: 650px; 
		height: 100px; 
		font-size: 36px; 
		padding-left:20px; 
		padding-right: 20px; 
		color: #6fa1e8;
		background-color: none;
		border-radius: 8px;  
		border:none; 
	}

	.nav1{
		width: 700px; 
		height: 88px;	
		flex-direction: row; 
		align-items: center; 
		justify-content: left;
		position: relative;	
		margin-top: 25px;
	}
	.nav1_li{
		/*position: relative;*/
		flex: 1; 
		height: 88px;
		flex-direction: row; 
		align-items: center; 
		justify-content: space-between; 
		padding-left: 20px; 
		padding-right: 20px;
		margin-left: 20px; 
		margin-right: 20px;	
		border-color: #6fa1e8;
		border-width: 1px;
		border-style: solid;
		border-radius: 8px;
	}
    .nav_name{
    	font-size: 34px; 
    	border-radius: 5px;  
    	color: #666;	
    	padding-left: 20px; 
    	padding-top: 8px; 
    	padding-bottom: 8px;
		padding-right: 20px;
	}

	.s_class{
		position: fixed;
	    z-index: 9999;
	    top: 554px;
		padding-left: 36px;
		padding-right: 36px;
		width: 300px;
		height: 500px;
		border-color: #e6e6e6;
		border-style: solid;
		border-width: 1px;
		background-color: #fff;

	}
	.s_class_opt{
		color: #666;
		font-size: 32px;
		width:280px;
		height: 80px;
		flex-direction:row;
		align-items: center;
		border-bottom-color: #e6e6e6;
		border-bottom-style: solid;
		border-bottom-width: 1px;

	}
	.type_yes{ 
		background-color: #40cc8b;
		color: #fff;	
	 }

	.btn{
		position: fixed;
		bottom:40px;
		left: 50px;
		 width: 650px; 
		 margin: 25px; 
		 text-align: center;
		 padding-top: 25px; 
		 padding-bottom: 25px; 
		 border-radius: 55px; 
		 color: #fff; 
		 font-size: 40px;  
		 background-color: #6fa1e8; 
		 border-color: #6fa1e8;
		border-style: solid;
		border-width: 1px; 
	}

</style>