<template>
	<div style=" background-color:#fafafa; ">
		<div class="top" >
			<text class="top_name" >我的</text>
		</div>
		<div class="topMain" style="background-color: #fff; " @click="jump('/main/grxx')">
			<!--<router-link to='/main/xgxx'>-->
				<image src="../static/images/head.png" class="info_img" />
				<div>
					<div style="flex-direction: row;" >
						<text class="name">王菲&nbsp;</text>
						<text class="nameType">状元</text>
					</div>
					<text class="name" style=" font-size: 32px; font-weight: normal; ">福田中心小学</text>
				</div>
			<!--</router-link>-->
		</div>
		<div class="j_f">
			<div class="j_f_i">
				<text class="j_fName">10.4万字</text>
				<text class="j_fName1" >阅读量</text>
			</div>
			<div class="j_f_i">
				<text class="j_fName">1000分</text>
				<text class="j_fName1">积分</text>
			</div>
			<!--<div class="j_f_i">
				<p>101天</p>
				<p>连续学习</p>
			</div>
			-->
		</div>

		<div class="main">
			<!--<router-link to='/main/wdxx'>-->
				<div class="main_list" style=" margin-bottom: 20px; "  @click="jump('/main/wdxx')">
					<div class="main_list_l">
						<image src="../static/images/xs_wd_tz.png" class="main_pic" ></image>
						<text class="main_title">消息中心</text>
					</div>
					<image src="../static/images/wd_09.png"  class="more"></image>
				</div>
			<!--</router-link>
			<router-link to='/main/fx'>-->
				<div class="main_list"  @click="jump('/main/wdfx')">
					<div class="main_list_l">
						<image src="../static/images/xs_wd_07.png" class="main_pic"></image>
						<text class="main_title" >我的分享</text>
					</div>
					<image src="../static/images/wd_09.png"  class="more" ></image>
				</div>
			<!--</router-link>
			<router-link to='/main/sc'>-->
				<div class="main_list" style=" margin-bottom: 20px;" @click="jump('/main/wdsc')">
					<div class="main_list_l">
						<image src="../static/images/xs_wd_09.png" class="main_pic"></image>
						<text class="main_title">我的收藏</text>
					</div>
					<div>
						<image src="../static/images/wd_09.png" class="more"></image>
					</div>
				</div>
			<!--</router-link>-->
			<!--<router-link to='/main/sz'>-->
				<div class="main_list" @click="jump('/main/sz')">
					<div class="main_list_l">
						<image src="../static/images/xs_wd_sz.png"  class="main_pic"></image>
						<text class="main_title">设置</text>
					</div>
					<div>
						<image src="../static/images/wd_09.png"  class="more"></image>
					</div>
				</div>
			<!--</router-link>-->
		</div>
		<foot :show="3"></foot>
	</div>
</template>

<script>
	import f from './footer.vue'
	export default {
		components: {
			'foot': f // 添加底部导航组件
		}
	}
</script>

<style scoped>
    .top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.topMain{
		width: 750px;
		border-bottom-style: solid;
		border-bottom-width: 1px;
		border-bottom-color: #f0f0f0;
		margin-bottom:20px;
		flex-direction: row;
		justify-content: left;
		align-items: center;
	}
	.info_img{
		width: 120px;
		height:120px;
		border-radius: 100%;
		margin-top: 20px;
		margin-bottom: 20px;
		margin-right: 30px;
		margin-left: 30px;
	}

	.name{
		font-size: 36px;
		color: #666;
		margin-top: 10px;
		font-weight: 500;
	}
	.nameType{
		height: 30px;
		border-radius: 3px; 
		font-size: 22px; 
		padding-top: 3px;
		padding-bottom: 3px;
		padding-left: 10px;
		padding-right: 10px;
		background-color: #f60; 
		color: #fff; 
		margin-top: 14px;
	}
	.j_f{
		flex-direction: row;
		flex-flow: row;
		width: 750;
		background-color: #fff;
		margin-bottom: 20px;
	}
	.j_f_i{
		flex: 1;
		flex-direction:column;
		align-items: center;
		justify-content: center;
	}

    .j_fName{
    	font-size: 34px;
    	color: #91b7ee;
    	font-weight: bold;
    	line-height: 65px; 
    }
    .j_fName1{
    	font-size: 28px;
    	color: #666;
    	margin-bottom: 15px;
    }
	.main{
		width: 750px;
	}
	.main_list{
		flex-direction: row;
		height: 95px; 
		align-items: center; 
		justify-content: space-between; 
        padding-right: 30px;
        padding-left: 30px;
        padding-top: 20px;
        padding-bottom: 20px;
		border-bottom-style: solid;
		border-bottom-width: 1px;
		border-bottom-color: #f0f0f0;
		background-color: #fff; 		
	}
	.main_list_l{
		flex-direction: row;
		align-items: center; 
		justify-content: left;
	}
	.main_title{
		font-size: 35px;
		color: #333333;
	}
	.main_pic{
		width: 36px; 
		height: 36px;
		margin-right: 30px; 
	}
	.more{
		 width: 15px; 
		 height: 27px; 
	}

	
</style>