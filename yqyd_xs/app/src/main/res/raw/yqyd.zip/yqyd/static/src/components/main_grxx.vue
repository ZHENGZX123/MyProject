<template>
	<div>
		<!-- 头部 -->
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback"/></image>
			<text class="que">个人资料</text>
			<text class="que" @click="subimt">确定</text>
		</div>
		<scroller>
			<!-- 头像 -->
			<div class="photo">
				<image :src="avatar" class="pImg"></image>
			</div>
			<!-- 姓名、性别 -->
			<div class="sexName">
				<div class="wrapper">
					<text style="font-size:32px;margin-bottom:10px">姓名</text>	
					<input class="input" type="text"  placeholder="姓名" v-model="studentName" />	
				</div>
				<div class="wrapper">
					<text style="font-size:32px;margin-bottom:10px">性别</text>	
					<!-- <input class="input" type="text" value="男"  /> -->
					<text @click="fn" class="input" style="padding:15px;">{{xzsex}}</text>
				</div>
			</div>
			<!-- 电话 -->
			<div class="List">
				<div class="wrapper">
					<text style="font-size:32px;margin-bottom:10px" >电话</text>	
					<input class="dh" type="text"  placeholder="电话" v-model="phone"/>	
				</div>
			</div>
			<!-- QQ -->
			<div class="List">
				<div class="wrapper">
					<text style="font-size:32px;margin-bottom:10px" >QQ</text>	
					<input class="dh" type="text"  placeholder="QQ" v-model="qq"/>	
				</div>
			</div>
			<!-- 邮箱 -->
			<div class="List">
				<div class="wrapper">
					<text style="font-size:32px;margin-bottom:10px" >邮箱</text>	
					<input class="dh" type="text"  placeholder="邮箱" v-model="email"/>	
				</div>
			</div>

			<!-- 学校 -->
			<div class="List" style="margin-bottom:110px;">
				<div class="wrapper">
					<text style="font-size:32px;margin-bottom:10px" >学校</text>	
					<input class="dh" type="text"  placeholder="学校" v-model="schoolName"/>	
				</div>
			</div>
		</scroller>
		

		<!-- 性别 -->
		<div class="s_class"  v-if="xb">
			<scroller>
				<div class="s_class_opt" v-for='state in stateList'  @click="optState(state.id,state.name)" :style="{ backgroundColor: state.bj, color: state.color}"  >
					<text :style="{ backgroundColor: state.bj, color: state.color}"  style=" font-size: 34px; ">{{state.name}}</text>
				</div>
			</scroller>
		</div>

	</div>
</template>
<script>
	const modal = weex.requireModule('modal')
	import kwz from '../../static/js/Utils.js'
	export default {
		data() {
			return {
				sex:false,
				xb:false,
				xzsex:'',
				typeId:'',
				stateId:'',
				studentName:'',
				phone:'',
				qq:'',
				email:'',
				sex:'',
				schoolName:'',
				Img:'',
				avatar:'',
				stateList:[
					{name:'男',bj:'',color:'#666',id:0},
					{name:'女',bj:'',color:'#666',id:1}
				],
			}
		},
		created:function(){
			var self = this
			kwz.fetch({
				url : '/app/student/uc/?loginAccount=10099521',
				method:'POST',
				type:'json',
			    data:'',
			    success:function(req){
			    	self.xzsex = req.data.result.sex;
			    	self.studentName = req.data.result.stuName;
			    	self.phone = req.data.result.phone;
			    	self.qq = req.data.result.qq;
			    	self.email = req.data.result.email;
			    	self.schoolName = req.data.result.schoolName;
			    	self.avatar = req.data.result.avatar;
			    }
			})
		},
		methods: {
			 goback () {
		      this.$router.go(-1);
		    },
		    fn() {
		    	if(this.xb==true){
		    		this.xb=false;
		    	}else{
		    		this.xb=true;
		    	}

		    },
		    optState:function(id,name){
		    	this.stateId=id;
		    	this.xzsex=name;
		    	this.xb=false;
		    	var self = this;
		    	for(var i in self.stateList){
		    		self.stateList[i].bj = '';
		    		self.stateList[i].color = '#666';
		    		if(i==id){
		    			self.stateList[id].bj = '#d9e8fd';
		    			self.stateList[id].color="#6fa1e8";
		    		}
		    	}
		    },
		    // 修改个人资料
		    subimt() {		    	
		    	var self=this;
		    	kwz.fetch({
		    		url : '/app/student/uc/updatePersonalInfo?loginAccount=10099521',
		    		method:'POST',
		    		type:'json',
		    		data:'name='+self.studentName+'&sex='+self.xzsex+'&phone='+self.phone+'&qq='+self.qq+'&email='+self.email,
			    	success:function(req){
			    		if (req.status==200) {
			    			modal.alert({
			    				message: '修改成功',
			    				duration: 0.3
			    			}, function (value) {
			    				self.$router.go(-1);
			    			})
			    		}else{
			    		}
			        }
				})
		    	
		    },
		}
	}
</script>

<style scoped>
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: space-between; 
		padding: 20px;
		box-sizing: border-box;
		
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.que{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		width: 37px;
		height: 37px; 
	}
	.grxx{
		width: 750px;
		flex-direction: row;
	}
	.photo{
		width: 750px;
		height: 150px;
		border-bottom-width: 1px;
		border-style: solid;
		border-color: #ccc;
		align-items: center; 
		justify-content: center; 

	}
	.pImg{
		width: 100px;
		height: 100px;
	}
	.sexName{
		width: 750px;
		height: 150px;
		flex-direction: row;
		justify-content: space-between;
		/* background-color: orange; */
	}
	.wrapper{
		flex-direction: column;
		padding: 20px;

	}
	
		/* margin-bottom: 110px; */
	
	.input {
		font-size: 34px;
		width: 300px;
		height: 80px;
		color: #666666;
		border-width: 2px;
		border-style: solid;
		border-color: #ccc;
		padding-left: 20px;

  }
  .dh{
  	font-size: 34px;
  	width: 710px;
  	height: 80px;
  	color: #666666;
  	border-width: 2px;
  	border-style: solid;
  	border-color: #ccc;
  	padding-left: 20px;
  }
  .s_class{
		position: fixed;
	    z-index: 9999;
	    top: 380px;
		width: 300px;
		right: 20px;
		/* padding: 5px; */
		height: 160px;
		border-color: #e6e6e6;
		border-style: solid;
		border-width: 2px;
		background-color: #fff;

	}
	.s_class_opt{
		width: 375px;
		height: 80px;
		flex-direction:row;
		align-items: center;
		justify-content: flex-start;
		padding-left: 20px;
		border-bottom-color: #e6e6e6;
		border-bottom-style: solid;
		border-bottom-width: 2px;
	}
</style>