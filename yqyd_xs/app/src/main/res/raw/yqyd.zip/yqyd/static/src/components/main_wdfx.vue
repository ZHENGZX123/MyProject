<template>
	<div>
		<!-- 头部 -->
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback"></image>
			<text class="top_name">我的分享</text>
		</div>
		<!-- 搜索 -->
		<div class="sear">
			<div class="searMain">
				<image src="../static/images/ico_look.png" class="look" />
				<input type="text" name="" class="pot_input" placeholder="搜索" />
			</div>
		</div>
		<!-- 分享列表 -->
		<div v-for="(item,v) in List">
			<scroller scroll-direction="horizontal" style="flex-direction: row;" class="scroll">
				<div style="flex-direction: row;">
					<div class="fenx">
						<div class="Img">
							<div class="tx">
								<image :src="item.url" class="txImg" />
								<text style="color: #79a8ec;font-size:32px;margin-left:20px;">{{item.name}}</text>
							</div>
							<text style="margin-right:25px;font-size:24px;">{{item.dataTimg}}</text>
						</div>
						<div class="News">
							<image :src="item.NewsImg" class="Nimg" />
							<text class="Ntext">{{item.NewsCont}}</text>
						</div>
					</div>
				</div>
				<div class="Delete">
					<image @click="DeleteFX(v)" src="../static/images/delete.png" class="deList"></image>
				</div>
			</scroller>
		</div>
	</div>
</template>
<script>
	const modal = weex.requireModule('modal')
	export default {
		data(){
			return {
				// show1:true,
				List:[
					{url:"../static/images/head.png",name:"王菲",NewsImg:"../static/images/21091W492-0.jpg",
					NewsCont:"奥斑马：阅读是帮助我撑过白宫8年的秘密",dataTimg:"2017-05-03"},
					{url:"../static/images/head.png",name:"李菲",NewsImg:"../static/images/21091W492-0.jpg",
					NewsCont:"奥斑马：阅读是帮助我撑过白宫8年的秘密",dataTimg:"2017-05-04"},
					{url:"../static/images/head.png",name:"张菲",NewsImg:"../static/images/21091W492-0.jpg",
					NewsCont:"奥斑马：阅读是帮助我撑过白宫8年的秘密",dataTimg:"2017-05-05"}
				]
			}
		},
		methods: {
			goback() {
				this.$router.go(-1);
			},
			// 删除分享列表
			DeleteFX(v) {
				
			},
		},
	}
</script>
<style scoped>
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.hua{
		width: 850px;
		background-color: #fff;
	}
	.wrapper{
		width: 750px;
		margin-top: 20px;
		align-items: center;
		position: relative;
	}
	.input {
		font-size: 50px;
		width: 650px;
		margin-top: 20px;
		/* margin-left: 50px; */
		padding-top: 20px;
		padding-bottom: 20px;
		/* padding-left: 20px; */
		padding-right: 20px;
		color: #666666;
		border-width: 2px;
		border-style: solid;
		border-color: #41B883;
	}
	.sear{
		width: 750px;
		height: 98px;
		background-color: #fff;
		border-bottom-width: 1px;
		border-style: solid;
		border-color: #e7e7e7;align-items: center;
	}
	.searMain{
		flex-direction: row;
		
		font-size: 36px;
		line-height: 88px;
		width: 680px;
		background-color: #f0f0f0;
		border-radius: 8px; 
		margin-bottom: 12px;
		margin-top: 12px;
		/* margin-left: 20px;  */
		margin-right: 20px;

	}
	.pot_input{
		width: 680px;
		height:70px; 
		font-size: 32px; 
		background-color: #f0f0f0;
		border:none;
	}
	.look{
		width: 40px; 
		height: 40px; 
		margin-left: 15px; 
		margin-right: 15px;
		margin-top: 17px;
	}
	.main{
		background-color: #fff; 
		padding-bottom: 30px;
	}
	.fenx{
		width: 750px;
		height: 250px;
		border-bottom-style: solid;
		border-bottom-width: 1px;
		border-bottom-color: #e7e7e7;
		padding: 25px;
		box-sizing: border-box;
	}
	.Delete{
		width: 160px;
		height: 250px;
		background-color: #f3f3ef;
		align-items: center;
		justify-content: center;
	}
	.deList{
		width: 100px;
		height: 100px;
	}
	.Img{
		width: 710px;
		height: 80px;
		flex-direction: row; align-items: center;justify-content: space-between;
		/* background-color: #000; */

	}
	.tx{
		flex-direction: row; 
		align-items: center;

	}
	.txImg{
		width: 80px;
		height: 80px;
	}
	.News{
		width: 680px;
		height: 120px;
		background-color: rgb(247, 247, 247);
		flex-direction: row; 
		align-items: center;
		border-radius: 5px; 
	}
	.Nimg{
		width: 120px;
		height: 80px;
		border-radius: 3px; 
	}
	.Ntext{
		width: 550px;
		/* color: #79a8ec; */
		font-size:32px;
		margin-left:20px;
		word-wrap:break-word;
	}
</style>