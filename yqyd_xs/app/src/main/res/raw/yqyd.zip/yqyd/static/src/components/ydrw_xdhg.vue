<template>
	<div style=" background-color: #fafafa; ">
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback"  @click="goback" />
			<text class="top_name">读后分享</text>
		</div>
		<scroller>
			<div class="content">
				<text style=" font-size: 34px; line-height:45px;color: #666; ">请说一说或者写一写，分享您的读后感：</text>
				<textarea class="textarea" placeholder="请输入读后感" v-model='content'></textarea>
				<div class="photoList">
					<div style="padding:10px; " v-for="(lPic,index) in imageUrl" @click="enlargePic(lPic,index)" >
						<image :src="lPic" style=" width: 152px; height: 150px; " ></image>
					</div>
					<div style="padding:10px; " @click="openPic" v-if="imageUrl.length!=8"><image src="../static/images/add_pic.png" style="width: 152px; height: 152px; "></image></div>
				</div>
				<div class="panel">
					<div>
						<div class="voice"  @click="playVoice(voiceUrl)" v-if="duration">
							<text style="font-size: 34px; color: #6fa1e8; ">{{duration}}'</text><image :src="VoicePic" class="pic_yy" />
						</div>
					</div>	
					<image src="../static/images/ico_02.png" class="voicePic" @click="openVoice" ></image>
				</div>
				<text class="confirm" @click="confirm" >提&nbsp;交</text>
			</div>
		</scroller>
	</div>
</template>

<script>
	const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				//imageList:{ src: '../static/images/pic_01.png'}
				//listPic:{imageUrl:'../static/images/add_pic.png',imageUrl:'../static/images/add_pic.png'},
				VoicePic:'../static/images/xs_pic_yy.png',
				checkYes:'../static/images/xs_pic_1.gif',
				checkNo:'../static/images/xs_pic_yy.png',
				content:'',
				voiceUrl:''	,
				imageUrl:[],
	        	loginA:'',
			    rwId:'',
			    bId:'',
             	rwtype:0,
             	bName:'',
             	duration:''
	        }
	    },
		methods: {
			 goback () {
			 	var sjevent = weex.requireModule('SJevent');
			 	if(sjevent){
			 		sjevent.StopVoice();
			 	}
			   
		        this.$router.go(-1);
		    },
		    openPic:function(){
		    	var self=this;
		    	var sjevent = weex.requireModule('SJevent');
		    	if(sjevent){
			    	sjevent.PostSigalImg(function(ret){
			    		self.imageUrl=ret.url.split(',');
			    		 modal.toast({
							message: ret.url,
							duration: 0.3
						})
					});
		    	}
		    },
		    openVoice:function(){
		    	var self=this;
		    	var sjevent = weex.requireModule('SJevent');
		    	if(sjevent){
			    	sjevent.PostSigalVoice(function(ret){
			    		self.voiceUrl=ret.url;
			    		self.duration=ret.duration;
			    		/* modal.toast({
							message: ret.url+ret.duration,
							duration: 0.3
						})*/
					});
		   		}
		    },
		    playVoice(url){
	        	var sjevent = weex.requireModule('SJevent');
				sjevent.PlayVoice( url ,function(ret){
					if(this.VoicePic==this.checkYes && ret=='ok'){
						this.VoicePic=this.checkNo;
					}else{
						this.VoicePic=this.checkYes;
					}
				}) ;	
	        },
	        enlargePic(lPic,index){
	        	var sjevent = weex.requireModule('SJevent');
				sjevent.showPhoto(lPic, index);  
	        },
		    confirm(){
				var self=this;
				self.rwId=self.$route.query.planId;
             	self.bId=self.$route.query.bookId;
             	self.rwtype=self.$route.query.bookType;
             	self.bName=self.$route.query.title;

 				if(self.content!=''|| self.duration!=''|| self.imageUrl.length!=0){
	                storage.getItem('username',function(e){  //从缓存中取userId
            			self.loginA = e.data;
					    kwz.fetch({
					    	url : '/app/student/feeling/add?planId='+self.rwId+'&bookId='+self.bId+'&loginAccount='+self.loginA+'&bookType='+self.rwtype+'&title='+self.bName+'&content='+self.content+'&voiceUrl='+self.voiceUrl+'&imageUrl='+self.imageUrl+'&duration='+self.duration,
					    	method:'POST',
					    	type:'json',
					    	data : '',
					    	success : function(ret){
					    		console.log(ret.data);
					    		 modal.toast({
							          message: '发布成功',
							          duration: 3
							     })
					    		 self.$router.replace('/index');
					    	},
					    	error:function(ret){
					    		//alert(ret)
					    	}

					    });

					});
       		  	}else{
		   			 modal.alert({
	                    message:'请说一说或者写一写，分享您的读后感',
	                    okTitle:'好的'
	                 },function(){})

				}
		    }
		}
	}
</script>

<style scoped>
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:22px;
		left: 25px;
		width: 44px;
		height: 44px;
	}
	.content{
		width: 750px;
		padding:30px;
	}
	.textarea{
		width: 700px;
		height: 417px;
		lines:8;
		border-color: #e6e6e6; 
		border-style: solid;
		border-width: 1px;
		padding: 24px;
		font-size: 34px;
		margin-top: 30px;
		border-radius: 10px;
	}
	.panel{
		width: 700;
		height: 88px;
		flex-direction: row;
		align-items: center;
		justify-content:space-between;
		margin-top: 30px;
		margin-bottom: 47px;
		padding-right: 20px;
	}
	.photoList{
		flex-direction: row;
		flex-wrap:wrap;
		margin-top: 20px;
	}
	.photo{
		width: 52px;
		height: 52px;
		margin-left: 60px;
	}
	.voicePic{
		flex-direction: row;
		justify-content:flex-start;
		width: 41px;
		height: 52px;
		margin-left: 60px;
	}
	.confirm{
		width: 700px;
		height: 100px;
		text-align: center;
		font-size: 39px;
		color: #fff;
		font-weight: 500;
		border-radius: 10px;
		background-color: #79a8ec;
		line-height: 100px;
		border: 0px;
	}
	.voice{
		width: 270px; 
		height: 80px; 
		flex-direction: row;
		align-items: center;
		justify-content: space-between;
		border-style: solid;
		border-color: #e8e8e8;
		border-width: 1px;
		
		border-radius: 8px; 
		background-color: #f5f5f5; 
		
		margin-top: 20px;
		padding-left: 20px;
		padding-right: 20px;
	}
	.pic_yy{
		width: 20px;
		height: 30px;
	}
</style>