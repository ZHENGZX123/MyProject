<template>
	<div>
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback" />
			<text class="top_name" >书香榜</text>
		</div>
			<div class="tab">
				<div class="tab_li" :style="{ backgroundColor: tab.bj, color: tab.color}" v-for="(tab,index) in tylelist" @click='cut(index,tab.id)'>
					<text style="font-size: 36px;color: #666;" :style="{ backgroundColor: tab.bj, color: tab.color}"  >{{tab.name}}</text>
				</div>
				
			</div>
			<div class="info_tit">
				<text class="info_tit_list" style=" flex: 1;">排名</text>
				<text class="info_tit_list" style=" flex: 3;">姓名</text>
				<text class="info_tit_list" style=" flex: 2;">积分</text>
				<text class="info_tit_list" style=" flex: 2;">阅读量(万)</text>
			</div>
			<div class="info_l_s" style=" background-color:#d9e8fd; margin-bottom: 20px; ">
				<div class="info_flex1">
					<text class="o_nbr">{{mine.index}}</text>
				</div>
				<div class="info_flex3" >
					<image class="s_tx" :src="mine.avatar" />
					<div style=" flex-direction: column; ">
						<text class="s_name">{{mine.stuname}}</text>
						<text class="designation">{{mine.level}}</text>
					</div>
				</div>
				<text class="s_rank">{{mine.score}}</text>
				<div class="info_flex2">
					<text class="s_grade">{{mine.words}}</text><text style="font-size: 28px; ">万</text>
				</div>
			</div>
			<scroller >
			    <div class="info_l_s" v-for="(l, i) in list" style=" background-color:#fff;" >
					<div class="info_flex1">
						<text class="o_nbr" v-if="i>2" >{{i+1}}</text>
						<image src="../static/images/pic_gold.png" class="pic_ph" v-if="i==0" />
						<image src="../static/images/pic_silver.png" class="pic_ph" v-if="i==1" />
						<image src="../static/images/pic_copper.png" class="pic_ph" v-if="i==2" />
					</div>
					<div  class="info_flex3" >
						<image class="s_tx" :src="l.avatar"/>
						<div style=" flex-direction: column; ">
							<text class="s_name">{{l.stuname}}</text>
							<text class="designation">{{l.level}}</text>
						</div>
					</div>
					<text class="s_rank">{{l.score}}</text>
					<div  class="info_flex2" >
						<text class="s_grade">{{l.words}}</text><text style="font-size: 28px; ">万</text>
					</div>
				</div>
			    <loading class="loading" @loading="onloading" :display="showLoading">
			      <text class="indicator">加载更多 ...</text>
			    </loading>
		   </scroller>
	</div>
</template>
<script>
  const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {			
				tylelist:[
					{name:'全班排行榜',bj:'#d9e8fd',color:'#6fa1e8',id:1},
                    {name:'全校排行榜',bj:'#fff',color:'#666',id:2}
				],
				mine: {
				  score:'',//
			      words: '',
			      index: '',
			      loginAccount: '',
			      avatar: '',
			      ability: '',
			      stuname: ''
			    },
				list: [
				/*	{id: '1', src: '../static/images/head_01.png', name: '欧阳锋芒锋芒', des: '状元', rank: 'A', grade: '100000'},*/
				],
				tabsId:0,
				tabsIndex:0,
				Account:'',
				page: 1,
				flag: false,	
				showLoading: 'hide'
				
			}
		},
		methods: {

			cut: function(index,id){
				//debugger
				this.tabsId=id;
				this.tabsIndex=index;
				var self = this;
				for(var i in self.tylelist){
					self.tylelist[i].bj = '';
                    self.tylelist[i].color = '#666';
					if(i==this.tabsIndex){
						self.tylelist[this.tabsIndex].bj = '#d9e8fd';
						self.tylelist[this.tabsIndex].color="#6fa1e8";
					}
				}
				if(!this.flag){
					this.list=[];
		    		this.page=1;
				}
                //console.log(njId);
				kwz.fetch({
			    	url : '/app/student/rank?loginAccount='+self.Account+'&page='+self.page+'&pageSize=10&type='+self.tabsId,
			    	method:'POST',
			    	type:'json',
			    	success : function(ret){
			    		var data =ret.data.result||[];
						 if(!self.flag&&self.tabsId==1){
			   			   self.mine=eval(data.mine);
						 }
						if(ret.data.status==200 && data.info.length!=0){
			    			for(let i=0;i<data.info.length;i++){
					    		self.list.push(data.info[i]);
					    	}
			    		}else if(ret.data.status==404 && data.info.length==0){
			    			 modal.toast({ message: '已到底部', duration: 1 });
			    		}
			    		self.flag=false;
			    		self.showLoading = 'hide';
			    	}
		    	})
			},
			 goback () {
		      this.$router.go(-1);
		    },
		   onloading (event) {
		   		var self = this;
		    	self.page+=1;
		    	self.flag=true;
		       // modal.toast({ message: 'loading', duration: 1 })
		        self.showLoading = 'show';
		        self.cut(self.tabsIndex,self.tabsId);	
		    }
		},
		created : function(){
			 var self =this;
			storage.getItem('username',function(e){  //从缓存中取userId
		        self.Account = e.data;
		        self.cut(0,1); 
		    }); 
		}
	
	}
</script>
<style scoped>
	
  	.loading {
  		width: 750px;
    	flex-direction: row;
   	 	align-items: center;
    	justify-content: center;
 	}
  	.indicator {
   		color: #888888;
	    font-size: 42px;
	    padding-top: 20px;
	    padding-bottom: 20px;
	    text-align: center;
 	 }

	.top{ 
		width: 750px;
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.tab{
		flex-direction: row;
		align-items: center;
		justify-content: center;
		height: 70px; 
		margin-left: 60px;
		margin-right: 60px;
		margin-top: 19px;
		margin-bottom: 19px;
		border-width: 1px;
		border-style: solid;
		border-color: #d9e8fd;
		border-radius: 40px; 
		background-color: #fff;

	}
	.tab_li{
		width: 315px; 
		text-align:center; 
		border-radius: 40px;
		height: 70px;
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}

	.info_tit{
		width: 750px;
		height: 70px;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		border-bottom-width: 1px;
		border-bottom-style: solid;
		border-bottom-color: #f6f6f6;
	}
	.info_tit_list{
		font-size:32px;
  		color: #666;
  		flex-direction: row;
  		text-align: center;
	}
	.info_l_s{ 
		flex-direction: row;
		align-items: center;
		width: 750px;
		height: 120px;
		border-bottom-color: #f1f1f1;
		border-bottom-width: 1px;
		border-bottom-style: solid;
	}
	.info_flex1{
		 flex: 1;  
		 flex-direction: row;
		 justify-content: center;
	}
	.info_flex2{
		flex: 2; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.info_flex3{
		flex: 3; 
		flex-direction: row; 
		align-items: center; 
	}

	.pic_ph{
		width: 43px; 
		height: 53px;
	}
	.o_nbr{
		flex-direction: row;
		justify-content: center;
		align-items: center;
		height: 52px;
		font-size: 32px;
		color: #808080;
	}
	.s_tx{
		float: left;
		margin-left: 10px;
		margin-right: 20px;
		width: 60px;
		height: 60px;
		border-radius: 100%;
	}
	.s_name{
		margin-top: 7px;
		font-size: 32px;
		color: #1a1a1a;
    	text-overflow: ellipsis;
    	lines:1;
	}
	.designation{
		margin-top: 11px;
		font-size: 30px;
		color: #ffb700;
	}
	.s_rank,{
		flex: 2;
		font-size: 40px;
		color: #f60;
		text-align: center;
		line-height: 80px;
	}
	.s_grade{
		color: #f60;
		font-size: 40px;
	}
	.checked{
		background-color: #d9e8fd; 
		color: #6fa1e8;	
		border-radius: 40px;
	}
</style>