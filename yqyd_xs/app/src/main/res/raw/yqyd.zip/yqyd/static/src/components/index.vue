<template>
	 <scroller style=" background-color: #f0f0f0; margin-bottom: 100px; ">
		<!-- 广告轮播图 -->
		<!--<ad></ad>-->
		 <slider class="slider" interval="3000" auto-play="true" >
	      <div class="frame" v-for="img in imageList">
	        <image class="image"  :src="img.src"></image>
	      </div>
	      <indicator class="indicator"></indicator>
	    </slider>
		<!-- 功能模块 -->
		<div class="content">
			<div class="fx_key">
				<image src="../static/images/xs_pic_more02.png" class="fx_img" />
			</div>
			<scroller scroll-direction="horizontal" class="panel" show-scrollbar="false">
				<div class="panel_li" @click="jump('/ydrw')">
					<image src="../static/images/pic_ydrw.png" class="icon_0"></image>
					<div  class="icon_1"></div>
					<text class="type_title">阅读任务</text>
				</div>
				<div class="panel_li" @click="jump('/kstfb')" >
					<image src="../static/images/ico_kstfb.png" class="icon_0"></image>
					<div class="icon_1"></div>
					<text class="type_title">考试提分宝</text>
				</div>
			
				<div class="panel_li" @click="jump('/ydbg')" >
					<image src="../static/images/pic_ydbg.png" class="icon_0"></image>
					<div class="icon_1"></div>
					<text class="type_title">学习报告</text>
				</div>
				<div class="panel_li" @click="jump('/ydzx')" >
					<image src="../static/images/ico_ydzx.png" class="icon_0"></image>
						<!--<div class="icon_1"></div>-->
					<text class="type_title">阅读资讯</text>
				</div>
				<div class="panel_li" @click="jump('/sxb')"  >
					<image src="../static/images/ico_phb.png" class="icon_0"></image>
					<!--<div class="icon_1"></div>-->
					<text class="type_title">书香榜</text>
				</div>
				<!--<div class="panel_li" @click="openSxb" >
					<image src="../static/images/ico_hdzq.png" class="icon_0"></image>
					<div class="icon_1"></div>
					<text class="type_title">活动专区</text>
				</div>-->
			</scroller>
			<div class="fx_key"><image src="../static/images/xs_pic_left.png"  class="fx_img"/></div>
		</div>
		<div class="jrrw">
			<div class="jrrw_title"><span class="title_img" >&nbsp;</span>&nbsp;&nbsp;<text style="font-size: 36px; color: #70a1e8;" >今日任务</text></div>
			<div  v-for="rw in rw_list"  class="jrrw_list" @click="jump('/ydrw/ckjh?planId='+rw.planId+'&type='+rw.type)" >
				<div class="jrrw_info">
					<div class="rw_title"><text style="font-size: 36px; color: #666; " >{{rw.planName}}</text></div>
					<div class="rw_time"><text style="font-size: 26px; color: #808080;">截止：{{rw.endDate}}</text><text style=" font-size: 26px; color: #808080;">{{rw.teaName}}</text></div>
				</div>
				<text class="c_bg">前 往</text>
				<image src="../static/images/xs_pic_newR.png" class="newR" />
			</div>
		</div>
		<div class="mrzx">
			<div  class="mrzx_l"><text class="mrzx_title">每日</text><text class="mrzx_title">之星</text></div>
			<div class="mrzx_r">
				<div class="mrzx_list" v-for="(s,index) in s_list">
					<image :src="s.avatar"  class="mrzx_list_tx"/>
					<text class="name">{{s.stuName}}</text>
					<image src="../static/images/pic_hg.png" class="pic_hg" v-if='index==0'/>
				</div>
			</div>
		</div>
		<div>
			<div class="jyzx">
				<div class="jrrw_title" >
					<span class="title_img" >&nbsp;</span>&nbsp;&nbsp;<text style="font-size: 36px; color: #70a1e8;">教育资讯</text>
				</div>
				<div @click="jump('/ydzx')" class="openYdzx" >
					<text class="yjzc_more">更多</text>
					<image src="../static/images/wd_09.png" class="yjzc_more_img" />
				</div>
			</div>
			<div  v-for="jyzx in jyzx_list" >
				<div class="jyzx_list" @click="jump('/ydzx/xq?id='+jyzx.id)" >
					<div class="jyzx_r">
						<text class="jyzx_titil"> {{jyzx.title}}</text>
						<div class="record">
							<div><text class="type_name" v-if="jyzx.tags">{{jyzx.tags}}</text></div>
							<div><text style="font-size: 28px; color: #828282;" v-if="jyzx.see" >{{jyzx.see}}阅读</text></div>
						</div>
					</div>
					<image :src="jyzx.image" class="jyzx_l"></image>
				</div>
			</div>
		</div>
		<foot :show='0'></foot>
    </scroller>

</template>

<script>
	const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	import foot from './footer.vue'
	export default {
		components: {
			'foot': foot
		},
		data(){
			return {
				imageList: [
	                { src: '../static/images/pic_01.png'},
	          		{ src: '../static/images/W020130321296490618267.jpg'},
	          		{ src: '../static/images/158_150401141239_1.jpeg'}
	        	],
				//每日之星
				s_list: [
					/*{src: '../static/images/head_04.png', name: '姜熙建', id: '../static/images/pic_hg.png'},*/
				],
				rw_list: [
					/*{href: '/kstfb_mr',title: '每日一练', time: '03-27 23:59',new: true},
					{title: '每周一测', time: '2017-03-31 23:59',new: true},
					{href: '/ydrw/ckjh',title: '阅读任务', time: '05-30 23:59',new: true,name:'张老师'}*/
				],
				// 功能模块列表
				/*p_list: [
					{href: 'tsg',title: '听书馆', src: '../../static/images/ico_dsg.png', flag: false},
					{href: 'hdzq',title: '活动专区', src: '../../static/images/ico_hdzq.png', flag: false}
				/*],*/
				jyzx_list: [
				    /*{title: '全民阅读不是一句口号', img:'../static/images/158_150401141239_1.jpeg', href:'/ydzx/xq',see:'3542',name:'一起阅读'},*/
				]
			//	loginA:'10099521'
			}
		},
		created : function(){

			/*var globalEvent = weex.requireModule('globalEvent');

  			globalEvent.addEventListener("clickback", function (e) {
  				var sjevent = weex.requireModule('SJevent');
  				if(sjevent){
        		 sjevent.finish();
  				}
    		});*/

			var loginA;
			var self = this
		   storage.getItem('username',function(e){  //从缓存中取userId
            	loginA = e.data;  
			    kwz.fetch({
			    	url : '/app/information/?page=1&pageSize=4',
			    	method:'POST',
			    	type:'json',
			    	data : '',
			    	success : function(ret){
			    		// const modal = weex.requireModule('modal');
			    		var data = ret.data.result
			    		self.jyzx_list=eval(data);
			    	}
			    })
			    kwz.fetch({
			    	url : '/app/student/index/task?loginAccount='+loginA,
			    	method:'POST',
			    	type:'json',
			    	data : '',
			    	success : function(ret){
			    		// const modal = weex.requireModule('modal');
			    		var data = ret.data.result
			    		self.rw_list=eval(data);
			    	}
			    })
			    kwz.fetch({
			    	url : '/app/student/dailystar?loginAccount='+loginA+'&pageSize=4',
			    	method:'POST',
			    	type:'json',
			    	data : '',
			    	success : function(ret){
			    		var data = ret.data.result
			    		self.s_list=eval(data);
			    	}
			    })
            });
		},
		methods: {
     		jump (path) {
        		this.$router.push(path);
      		}
    
	    }
	    /* beforeDestroy(){
	     	var globalEvent = weex.requireModule('globalEvent');
	    	globalEvent.removeEventListener("clickback", function (e) {
  				
    		});
	    }*/
	}
</script>

<style scoped>
	/*我的班级*/
  .image {
    width: 750px;
	height: 320px;
  }
  .slider {
	width: 750px;
	height: 320px;
  }
  .frame {
    width: 750px;
    height: 320px;
    position: relative;
  }
  .indicator {
    width: 700px;
    height: 20px;
    item-color: #ccc;
    item-selected-color: #f60;
    item-size: 12px;
    position: absolute;
    bottom: 20px;
    left:20px;
  }
  .content{
		margin-bottom: 20px;
		height: 200px; 
		background-color: #fff;
		flex-direction: row;
	}
	.cont_fx{
		flex-direction: row; 
		align-items:center; 
		justify-content: space-between;
        height: 200px;
		z-index: 99; 
	}  
	.fx_img{ 
		width: 20px; 
		height: 36px;
	}
	.panel{
		flex-direction: row;
        align-items: center; 
        justify-content: left;
		width: 650px; 
		height: 200px;
	}
	.panel_li{
		margin: 35px 13px;
		align-items: center; 
		justify-content: center;
		width: 170px;
	}
	.icon_1{
		position: absolute; 
		top: 0px;
		right: 40px;
		display: inline-block;
		width: 17px;
		height: 17px;
		background-color: #ff6666;
		border-radius: 100%;
	}
	.icon_0{
		width: 88px;
		height: 88px;
	}
	.type_title{
		margin-top: 16px;
		font-size: 30px;
		color: #838383;
	}
	.fx_key{
		width: 50px; 
		height: 200px;
		flex-direction: row; 
		align-items: center; 
		justify-content: center;
	}
	.jrrw{
		width: 750px;
		background-color: #fff;
		position: relative;
	}
	.jrrw_title{
		flex-direction: row;
		height: 35px;
		margin-top: 25px;
		margin-bottom: 25px;
		padding-left: 20px;
	}
	.title_img{
		background-color: #70a1e8; 
		margin-right: 1px; 
		width: 5px;
	}
	.jrrw_list{
		width: 700px;
		height: 130px;
		margin-left:24px;
		background-color:#f1f6fd;
		border-style: solid;
		border-width: 1px;
		border-color: #d9e8fd;
		border-radius: 12px;
		margin-bottom: 20px;
		padding: 30px;
		padding-top: 10px; 
		padding-bottom: 10px;
	}
	.newR{
		position: absolute;
		right: 0; 
		top: 0;
		width: 75px; 
		height:75px;
	}
	.jrrw_info{
		width: 540px;
	}
	.rw_title{
		flex-direction: row;
		height: 55px;
		align-items: center;
	}
	.rw_time{ 
		flex-direction: row;
		align-items: center; 
		justify-content: space-between;
		width: 450px; 
		height: 60px;
	}
	.c_bg{
		position: absolute;
		right: 40px;
		width: 100px;
		text-align: center;
		top: 50%;
		text-align: center;
		height: 45px;
		line-height: 45px;
		font-size: 28px; 
		border-radius: 8px;
		background-color: #70a1e8;
		color: #fff;

	}
	.mrzx{
		flex-direction: row;
		align-items: center; 
		justify-content: center;
		margin-top: 20px;
		border-style: solid;
		border-color: #e7e7e7;
		border-bottom-width: 1px;
		background-color: #fff;
	}
	.mrzx_l{
		flex-direction: column-reverse;
		align-items: center; 
		justify-content: center;
		height: 88px;
        padding:30px;
	}
	.mrzx_title{
		font-size:36px;  
		line-height: 45px;
		color:#70a1e8; 
	}
	.mrzx_r{
		height:180px;
		flex-direction: row;
		align-items: center;
		justify-content: center;
	}
	.mrzx_list{
		width: 140px;
		height: 180px;
		align-items: center; 
		justify-content: center;
	}
	.mrzx_list_tx{
		width: 101px;
		height: 101px;
		border-radius: 55px;
		position: relative;
		z-index: 8;
	}
	.name{
		font-size: 28px;
		color: #666;
		margin-top: 15px;
	}
	.pic_hg{
		width: 45px;
		height: 45px;
		position:absolute; 
		left: 45px; 
		top:-5px; 
		z-index: 99; 
	}
	
	.jyzx{
		width: 750px; 
		height: 88px; 
		background-color: #fff;
		margin-top: 20px;
		border-style: solid;
		border-color: #e7e7e7;
		border-bottom-width: 1px;
		padding: 0 20px ; 
		font-size: 36px;
		flex-direction: row;
		align-items: center; 
		justify-content: space-between;
	}

	.yjzc_more{
		font-size:28px; 
		color: #838383;  
	}
	.yjzc_more_img{
 		width: 16px; 
 		height: 26px; 
 		margin-left: 10px;
	}

	.jyzx_list{
		background-color: #fff; 
		border-style: solid;
		border-color: #e7e7e7;
		border-bottom-width: 1px;
		flex-direction: row;
		align-items: center; 
		justify-content: space-between;
	}
	.jyzx_l{
		width: 180px; 
		height:118px; 
		border-radius: 3px;  
		margin:20px; 
	}
	.jyzx_r{
		flex: 3;
		margin-left: 20px; 
		margin-right: 10px; 
	}
	
	.jyzx_titil{
		color:#333; 
		font-size:34px; 
		line-height:60px; 
		text-overflow:ellipsis; 
		lines:1;
	}
	.record {
		flex-direction: row;
		align-items: center; 
		justify-content: space-between;
		height: 60px;
	}
	.type_name{
		background-color: #70a1e8; 
		color: #fff; 
		padding-left: 8px;
		padding-right: 8px;
		padding-top: 4px;
		padding-bottom: 4px;
		border-radius: 5px;
	}
	.openYdzx{
		flex-direction:row;  
		align-items: center; 
		justify-content: center; 
		padding-right: 20px;
	}
</style>