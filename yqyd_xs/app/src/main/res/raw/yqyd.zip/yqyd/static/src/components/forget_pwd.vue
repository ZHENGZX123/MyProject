<template>
	<div id="ydzx" style=" background-color: #fafafa; font-family: 黑体; ">
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback" />
			<text class="top_name">忘记密码</text>
		</div>
	
		<div class="main" style=" ">
			<image src="../static/images/pic_Wxts.png" style=" width:175px; height: 240px;"></image>
			<div style=" padding: 30px; ">
				<text style=" font-size: 36px; color:#666; ">忘记密码请联系老师,</text>
				<text style=" font-size: 36px; color:#666; ">老师是你的好帮手！</text>
			</div>
		</div>
	</div>
</template>
<script>
    const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				// 活动列表
				ydzxXq: {}
			}
		},
		name: 'ydzx_xq',
		methods: {
		    goback () {
		       this.$router.go(-1);
		    }
		}
	}
</script>
<style scoped >
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		width: 550px;
		margin-left:100px;
		margin-right:100px;
		text-overflow: ellipsis;
		lines:1;
		font-size: 36px;
		color: #fff;
		text-align: center;
	}
	.goback{
		position: absolute;
		top:25px;
		left: 25px;
		width: 37px;
		height: 37px;
	}
	.main{
		 width: 650px; 
		 margin: 50px; 
		 margin-top: 280px; 
		 flex-direction: row; 
		 align-items: center; 
		 justify-content: center;
	}
	
</style>