<template>
	<div>
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback"  @click="goback" />
			<text class="top_name">任务详情</text>
			<image src="../static/images/ico_heart01.png" class="goback_r" />
			<!--<image src="../static/images/ico_2101.png" class="goback_r1" />-->
		</div>
		<scroller>
			<div>
				<image src="../static/images/bj.png" class="ydrw_zt" />
				<div class="ydrw_zt_title">
					<text class="ydrw_ztName">{{planName}}</text>
					<text class="ydry_ztlist">{{teacher.TEA_NAME}}|{{teacher.SCHOOL_NAME}}</text>
				</div>
			</div>
			<div  class="ydrw_lump">
				<div  class="jrrw_title">
					<span class="title_img" >&nbsp;</span>&nbsp;&nbsp;<text class="fontsz">任务时间：{{beginDate}}至{{endDate}}</text>
				</div>
			</div>

			<div class="ydrw_lump">
				<div class="jrrw_title">
					<span class="title_img" >&nbsp;</span>&nbsp;&nbsp;<text class="fontsz">老师推荐语</text>
				</div>
				<div class="lstj">
					<div class="lstj_l">
						<image :src="teacher.HEAD_URL" class="lstj_lpic" />
						<text class="lstj_lname" >{{teacher.TEA_NAME}}</text>
					</div>
					<div style=" flex: 3;  margin-right: 20px; ">		
						<text class="ydrw_lump_comt">{{reason}}</text>
						<div class="voice" @click="playVoice(voiceReason)" v-if="reasonDuration">
							<text style="font-size: 34px; color: #6fa1e8; ">{{reasonDuration}}'</text><image :src="VoicePic" class="pic_yy" />
						</div>
					</div>
				</div>
			</div>
			<div class="ydrw_lump">
				<div class="jrrw_title"><span class="title_img" >&nbsp;</span>&nbsp;&nbsp;<text class="fontsz">考核心方式： {{access | types}}</text></div>
			</div>
			<div class="ydrw_lump">
				<div class="jrrw_title" ><span class="title_img" >&nbsp;</span>&nbsp;&nbsp;<text class="fontsz">阅读要求</text></div>
				<div>		
					<text class="ydrw_lump_comt ">{{requirements}}</text>
					<div class="voice" @click="playTvoice(requirementsVoice)" v-if="requirementsDuration">
						<text style="font-size: 34px; color: #6fa1e8; ">{{requirementsDuration}}'</text><image :src="VoicePic" class="pic_yy" />
					</div>	
				</div>
			</div>
			<div class="jrrw_title"  style="margin-left: 20px; margin-right: 20px; margin-bottom: 20px;">
				<span class="title_img" >&nbsp;</span>&nbsp;&nbsp;<text class="fontsz">本期图书:共{{books.length}}本</text>
			</div>
			<div v-for="(book,index) in books" >
				<div class="bookName">
					<text style=" font-size: 32px;">&nbsp;&nbsp;图书{{index+1}}</text>&nbsp;&nbsp;&nbsp;&nbsp;<text style="flex: 3; font-size: 34px; text-overflow: ellipsis;lines:1;  ">{{book.bookName}}</text>
				</div>
					<div class="book_lump" >
						<div class="ydjy_l">
							<image :src="book.pic"  class="book_lump_img" style="position: relative;" ></image>
							<text class="ydjy_state" v-if="!book.testFinish==0 && !book.feelingFinish==0" >{{book.testFinish,book.feelingFinish |ydName}}</text>
						</div>
						<div class="book_lump_info">
							<text class="b_list">作者：{{book.author}}/著 </text>
							<text class="b_list">出版社：{{book.press}}</text>
							<text class="b_list">ISBN:{{book.isbn}}</text>
							<div class="ts_type">
								<text class="ts_label">{{book.bookType}}</text>
							</div>	
							<div class="record" >
								<div class="record_li"><image src="../static/images/ico_see.png" class="pic_see" ></image>&nbsp;<text>{{book.readCount}}</text></div>
								<div class="record_li"><image src="../static/images/ico_heart.png" class="pic_praise"></image >&nbsp;<text>{{book.toast}}</text></div>
							</div>
						</div>
					</div>
					<div class="ydrw_lump">
						<div class="jrrw_title"><span class="title_img" >&nbsp;</span>&nbsp;&nbsp;<text class="fontsz">内容简介</text></div>
						<text class="ydrw_lump_comt" style="text-overflow: ellipsis; lines:5;">{{book.desc}}</text>
					</div>
					<div class="yerw_yd">
						<text class="ydrw_btn" @click="openYdxq('/ydrw_xq?bookId='+book.bookId+'&type='+book.type+'&access='+access+'&feelingFinish='+book.feelingFinish+'&testFinish='+book.testFinish+'&bookName='+book.bookName+'&planId='+rwId)" >开始阅读</text>
					</div>
			</div>
			<div class="px_smq">
				<image src="../static/images/yyyd_gzh.jpg" class="pic_ewm" />
				<div class="ewm_name">
					<text style=" font-size: 32px; color: #666; line-height: 50px; ">长按识别二维码，关注[一起阅读]</text>
					<text style=" font-size: 32px; color: #666; line-height: 50px;">免费获取 200本精品图书阅读内容</text>
				</div>
			</div>
			<!--<div class="footes">
				<text class="footes_btn " @click="openYdxq">开始阅读</text>
			</div>-->
		</scroller>
	</div>
</template>

<script>
	const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				VoicePic:'../static/images/xs_pic_yy.png',
				checkYes:'../static/images/xs_pic_1.gif',
				checkNo:'../static/images/xs_pic_yy.png',

				requirementsVoice: '',
			    reason: '',
			    loginAccount: '',
			    requirements: '',
			    readState: 0,
			    access: '',
			    endDate: '',
			    reasonDuration: 0,
			    requirementsDuration: 0,
			    planName: '',
			    beginDate: '',
			    teacher: {
			      TEA_NAME: '',
			      SCHOOL_NAME: '',
			      QQ: '',
			      PHONE: '',
			      SEX: '',
			      HEAD_URL: '',
			      EMAIL: '',
			      SCHOOL_ID: ''
			    },
			    books: [],
			    voiceReason: '',
			    loginA:'',
			    rwId:'',
			}
		},
		methods: {
			goback () {
			    var sjevent = weex.requireModule('SJevent');
			    if(sjevent){
			   		sjevent.StopVoice();
				}
		       this.$router.go(-1);     
		    },
	        openYdxq(path){
	        	this.$router.push(path);
	        },
	        playVoice(url){
	        	var sjevent = weex.requireModule('SJevent');
	        	if(sjevent){
					sjevent.PlayVoice( url ,function(ret){
						if(this.VoicePic==this.checkYes && ret=='ok'){
							this.VoicePic=this.checkNo;
						}else{
							this.VoicePic=this.checkYes;
						}
					}) ; 	
				}
	        },
	         playTvoice(url){
	        	var sjevent = weex.requireModule('SJevent');
	        	if(sjevent){
		        		sjevent.PlayVoice( url ,function(ret){
						if(this.VoicePic==this.checkYes && ret=='ok'){
							this.VoicePic=this.checkNo;
						}else{
							this.VoicePic=this.checkYes;
						}
					}) ;	
	        	}
				
				//StopVoice()
	        }
		},
		created: function(){
			 var self = this;
				this.rwId=self.$route.query.planId;
				storage.getItem('username',function(e){  //从缓存中取userId
            		self.loginA = e.data;
            		//console.log('-------------'+self.loginA);
	            	kwz.fetch({
				    	url : '/app/plan/review?planId='+self.$route.query.planId+'&loginAccount='+self.loginA,
				    	method:'POST',
				    	type:'json',
				    	success : function(ret){
				            // debugger  
	                        var retdata=ret.data.result;
				    		//console.log(self.beginDate);
				    		self.requirementsVoice=retdata.requirementsVoice;
		             		self.beginDate=retdata.beginDate;
		    				self.reason=retdata.reason;
		    				self.loginAccount=retdata.loginAccount;
		    				self.requirements=retdata.requirements;
		   					self.readState=retdata.readState;
		    				self.access=retdata.access;
		    				self.endDate=retdata.endDate;
	    					self.planName=retdata.planName;
	    					self.voiceReason=retdata.voiceReason;
	    					self.reasonDuration=retdata.reasonDuration;
			    			self.requirementsDuration=retdata.requirementsDuration;

		    			    self.teacher=eval(retdata.teacher);
				    		self.books=eval(retdata.books);
				    	}
				  	})
				})
		},
		filters:{
			types:function(v){
				if(v=='1'){
					return '做测评';
				}else if(v=='2'){
					return '读后分享';
				}else if(v=='1,2'){
					return '做测评,读后分享';
				}else if(v=='2,1'){
					return '读后分享,做测评';
				}
			},
			ydName:function(n,x){
				if( n==1 && x==1){
					return '完成阅读';
				}
			}
		}
	}
</script>

<style scoped>

    /*头部*/
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:22px;
		left: 25px;
		width: 44px;
		height: 44px;
	}
	.goback_r{
		position: absolute;
		top:22px;
		right: 25px;
		width: 44px;
		height: 44px;
	}
	.goback_r1{
		position: absolute;
		top:22px;
		right: 100px;
		width: 44px;
		height: 44px;
	}
	.ydrw_zt{
		width: 750px;
		height: 300px; 
		position: relative; 
	}
	.ydrw_zt_title{
		width:750px;  
		position: absolute; 
		top:0; 
		left: 0; 
		padding-top: 40px;
		padding-bottom: 40px;
		color: #fff;
	}

	.ydrw_ztName{
		font-size: 45px; 
		line-height: 160px; 
		letter-spacing:12px;
		font-weight:bold; 
		text-align: center;
		color: #fff;
	}
	.ydry_ztlist{ 
		font-size: 32px; 
		text-align: center;
        color: #fff;
	}
	.ydrw_lump{
		border-bottom-color: #e6e6e6;
		border-bottom-width: 1px;
		border-bottom-style: solid;
		margin:20px; 
		margin-bottom: 0px;
		padding-bottom: 20px; 
	}
	.fontsz{
		 font-size: 34px; 
	}
	.bookName{
		font-size: 36px; 
		width: 750px; 
		height: 88px; 
		background-color: #e7f1ff; 
		flex-direction: row;
		align-items: center;
		justify-content: left; 
		text-indent: 20px;
		color: #666;
	}
	.book_lump{
		width: 750px;  
		height: 290px; 
		background-color: #fff; 
		position: relative;
		padding-right: 30px;
		padding-left: 30px;
		padding-top: 25px;
		padding-bottom:25px;
		border-bottom-style: solid;
		border-bottom-color: #ececec;
		border-bottom-width: 1px;
		flex-direction: row;
	}
	.jrrw_title{
		flex-direction: row;
		height: 35px;
		margin-top: 25px;
		margin-bottom: 25px;
	}
	.ydjy_l{
		width: 190px; 
		height:240px; 
		flex-direction: row;
		align-items: center;
		justify-content: center;
	}
	.book_lump_img{
		width: 190px; 
		height:240px; 
	}
	.book_lump_info{
		width: 500px;
		padding-left: 30px;
	}
	.ydjy_state{
		 position:absolute; 
		 top:20px; 
		 left: 0px;
		 background-color: #f60; 
		 color:#fff; 
		 font-size: 26px; 
		 padding-right: 15px;
		 padding-left: 15px;
		 padding-top: 5px;
		 padding-bottom: 5px;

	}

	.ydrw_lump_comt{
		margin-bottom: 20px;
		margin-top: 20px;
		line-height: 40px;
		text-align:justify;
		font-size: 32px; 
		color: #666666;
	}
	.lstj{
		width: 750px; 
		font-size: 32px; 
		flex-direction: row;
	}
	.lstj_l{
		flex-direction: column; 
		width: 180px; 
		padding-right: 30px;
		padding-left: 30px;
		padding-top: 20px;
		padding-bottom: 20px;
	}
	.lstj_lpic{
		width: 120px; 
		height: 120px; 
		border-radius: 60px; 
		position: relative; 
	}
	.lstj_lname{
		background-color: #70a1e8; 
		font-size: 32px; 
		padding: 10px;
		padding-top: 5px;
		padding-bottom: 5px;
		border-radius: 8px;
		color: #fff; 
		text-align: center; 
		position: relative; 
		left:0; 
		bottom: 20px;
	}

	.b_list{ 
		font-size:30px; 
		color: #666; 
		line-height: 47px;
		text-overflow: ellipsis;
		lines:1;
	}
	.yerw_yd{
		 flex-direction: row; 
		 align-items: center; 
		 justify-content: center;
		 height: 120px 
	}

	.ydrw_btn{
		background-color: #f60; 
		font-size: 36px; 
        padding-right: 120px;
        padding-left: 120px;
        padding-top: 20px;
        padding-bottom: 20px;
		border-radius: 8px;
		color: #fff; 
	}
	.px_smq{
		width: 750px;
		flex-direction: row; 
		padding: 20px; 
		background-color: #f0f0f0;
		/*margin-bottom: 100px;*/
	}
	.ewm_name{
		flex:3;
		flex-direction:column;
		text-align:justify; 
		align-items: center;
		padding:20px; 
	}
	.pic_ewm{
		width: 145px; 
		height: 145px;
		margin-right: 20px;
		margin-left: 10px;
	}
	.footes{
		width: 750px; 
		height: 98px; 
		position: fixed; 
		bottom: 0;
		background-color: #70a1e8;  
		flex-direction: row; 
		justify-content: center;
		align-items:center;

	}
	.footes_btn{
		width: 450px; 
		height: 80px; 
		border-style: solid;
		border-color: #fff;
		border-width: 1px;
		font-size: 36px; 
		border-radius: 8px;
		color: #fff; 
		text-align: center;
		line-height: 70px;
	}
	.voice{
		width: 270px; 
		height: 80px; 
		flex-direction: row;
		align-items: center;
		justify-content: space-between;
		border-style: solid;
		border-color: #e8e8e8;
		border-width: 1px;
		border-radius: 8px; 
		background-color: #f5f5f5; 
		margin-top: 20px;
		padding-left: 20px;
		padding-right: 20px;
	}
	.pic_yy{
		width: 20px;
		height: 30px;
	}
	.title_img{
		background-color: #70a1e8; 
		margin-right: 1px; 
		width: 5px;
	}
	
	.ts_type{
		flex-direction: row;
		justify-content: left;
		align-items: center;
	}
	.ts_label{
		font-size:26px; 
		background-color:#d9e8fd; 
		color: #666; 
		padding-bottom: 4px;
		padding-top: 4px;
		padding-left: 15px;
		padding-right: 15px; 
		margin: 10px; 
		margin-left: 0; 
		border-radius: 5px;
	}
	.record{
		flex-direction: row;
		height: 45px;
		line-height: 45px;
		font-size: 30px; 
		color: #999; 
		font-family: 微软雅黑; 
	}
	.record_li{
		flex: 1;
		flex-direction:row;
		justify-content: left;
		align-items: center;
	}
	.pic_see{
		width: 33px; 
		height: 22px; 
	}
	.pic_praise{
		width: 28px; 
		height: 23px; 
	}
</style>
