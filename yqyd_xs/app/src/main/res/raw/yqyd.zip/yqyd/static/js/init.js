// 设计稿上页面宽度为750px   设根元素的font-size为100px
document.documentElement.style.fontSize = document.documentElement.clientWidth / 7.5 + "px";