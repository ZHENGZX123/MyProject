<template>
	<div>
		<div class="top">
			<image src="../static/images/pic_ss.png" class="goback" @click="goback" />
			<text class="top_name">个人资料</text>
			<text class="goback_r" />确定</text>
		</div>

		<div class="tx">
			<image src="../static/images/head.png" class="tx_img" />
		</div>

		<div class="main">
			<div class="n_s">
				<div class="name">
					<text>姓名<span>*</span></text>
					<input type="text" name="" value='王菲'/>
				</div>
				<div class="sex">
					<text>性别<span>*</span></text>
					<select>
						<option>男</option>
						<option>女</option>
					</select>
				</div>
			</div>
			<text>电话<span>*</span></text>
			<input type="text" name="" value="13811111111"/>
			<text>密码<span>*</span></text>
			<input class="pas" type="password" name="" value="13811111111"/>
			<text>QQ<span>*</span></text>
			<input type="text" name="" value="13811"/>
			<text>邮箱<span>*</span></text>
			<input type="text" name="" value="13811@qq.com"/>
			<text>学校<span>*</span></text>
			<input type="text" name="" value="深圳宝安小学"/>
		</div>
	</div>
</template>
<script>
	export default {
		methods: {
			 goback () {
		      this.$router.goBack()
		    }
		}
	}
</script>

<style scoped>
	header{
		background-color: #fff;
		border-bottom: 1px solid #e7e7e7;
	}
	.goback{
		/*background-image: url('../../static/images/xs_pic_fh01.png');*/
	}
	header p{
		color: #333333;
		font-weight: 500;
	}
	.qd{
		position: absolute;
		top: 30px;
		right: 30px;
		font-size: 35px;
		color: #79a8ec;
	}
	.tx{
		position: relative;
		margin-top: 88px;
		width: 750px;
		padding-top: 52px;
		padding-bottom: 52px;
		background-color: #fff;
	}
	.tx_img{
		display: block;
		margin: 0 auto;
		width: 170px;
		height: 170px;
		border-radius: 100%;
	}
	.tx a{
		display: block;
		position: absolute;
		top: 180px;
		right: 280px;
		width: 50px;
		height: 50px;
		/*background-image: url('../../static/images/wd_10.png');
		background-size: 100% 100%;*/
	}
	.main{
		padding: 3px;
		background-color: #fff;
	}
	.main p{
		font-size: 28px;
		color: #b7b7b7;
	}
	.main p span{
		color: #79a8ec;
	}
	.main input,.main select{
		height: 90px;
		width: 100%;
		font-size: 35px;
		color: #333333;
		border: 0px;
		border: 1px solid #e7e7e7;
		border-radius: 5px;
		padding-left: 30px;
		margin-top: 15px;
		margin-bottom: 47px;
	}
	.n_s input{
		width: 330px;
	}
	.n_s{
		width: 100%;
		display: flex;
		flex-flow: row;
	}
	.name{
		flex: 1;
	}
	.sex{
		flex: 1;
	}
	select{
		background-color: #fff;
	}
	.main .pas{
		/*background-image: url('../../static/images/wd_11.png');
		background-size: 0.4rem 0.17rem;*/
		background-repeat: no-repeat;
		background-position: 6rem center;
	}
</style>