<template>
	<div id="sc" style=" background-color: #fff; padding-bottom: 120px; ">
		<!--<div class="top">
			<div class="topMain">
				<image src="../static/images/ico_look.png" class="look" />
				<input type="text" name="" v-model="title" class="pot_input" placeholder="请输入书籍名称" />
			</div>
			<text class="goback_r"  @click="goback">取消</text>
		</div>
		-->
		<myedittext :content='ss' @cancel='cancel' @search='search' style='height:100px;width: 750px;'></myedittext>
		<scroller>
			<div class="ydjy_list" v-for="sc in sc_list">
				<div class="ydjy_l">
					<img :src="sc.pic" class="ydjy_lPic" style=" position: relative; " ></img>
					<!--<text v-if="sc.state" class="ydjy_state"  >{{sc.state}}</text>-->
					<div class="play" @click="onpeScxq('/sk/xq?id='+sc.id+'&type='+tabsId)"></div>
					<image :src="sc.tabImg" class="ico_22" />
				</div>
				
				<div class="ydjy_r">
					<text class="hdzq_titil" @click="onpeScxq('/sk/xq?id='+sc.id+'&type='+tabsId)" >{{sc.name}}</text>
					<div class="author"><text class="fontSize">{{sc.author}}</text><text style="font-size: 30px; color: #666;">著</text></div>
					<div class="b_list"><text class="fontSize">ISBN:</text><text style="font-size: 32px; color: #666; ">{{sc.isbn}}</text></div>
					<div style="flex-direction: row; justify-content: left; align-items: center;">
						<text class="ts_label">{{sc.bookType}}</text>
					</div>	

					<div class="record" >
						<div class="record_li">
							<image src="../static/images/ico_see.png" class="pic_see" ></image>&nbsp;&nbsp;<text>{{sc.view}}</text>
						</div>
						<div class="record_li" @click="praise(sc,tabsId)">
							<image :src="checkYes" class="pic_praise" v-if="sc.isZan==1" ></image ><image :src="checkes" class="pic_praise" v-if="sc.isZan==0" ></image >&nbsp;&nbsp;<text>{{sc.toast}}</text>
						</div>
					</div>
				</div>
			</div>
			<loading class="loading" @loading="onloading" :display="showLoading">
			    <text class="indicator">加载更多 ...</text>
			</loading>
	    </scroller>
	</div>
</template>
<script>
	import f from './footer.vue'
	const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	const animation = weex.requireModule('animation');
	export default {
		data(){
			return {
				checkes:'../static/images/ico_heart.png',
				checkYes:'../static/images/ico_heart_yes.png',
				
	
            	isShow:false,
            	/*flagSrc: '../static/images/Selected.png',
            	arrowSrc: '../static/images/down.png',*/
				// 阅读教研 列表
				sc_list: [],
				flag:0,
				subjId:'',
				njName:'',
				tabsId:0,
				tabsIndex:0,
				page: 1,
				schoolId:'',
				flag: false,
				showLoading: 'hide',
				Account:'',
				title:'',
				isbn:''
			}
		},
		name: 'sc',
		methods: {
			
	      /*  goback () {
		      this.$router.go(-1);
		    },*/
		    cancel(e){
		    	this.$router.go(-1);
		    },
		    search(e){
				//storage.setItem('title',e.content);
				modal.toast({
		    		message:e.content
		    	});
				//this.$router.push('/sk/sm_search');
		    	
		    },
		    praise:function(sc,tabsId){
		    	var self=this;
		    	if(sc.isZan==0){
		    		//var self=this;
						//storage.getItem('username',function(e){  //从缓存中取userId
				       //      self.Account = e.data;
					    	 kwz.fetch({
						    	url : '/app/book/zan?bookId='+sc.id+'&loginAccount='+self.Account +'&bookType='+tabsId,
						    	method:'POST',
						    	type:'json',
						    	success : function(ret){
						    		sc.isZan = 1
									sc.toast = sc.toast+1;
						    	}
					    	})
				    	//})

		    	}else{
			    	 kwz.fetch({
				    	url : '/app/book/zan?bookId='+sc.id+'&loginAccount='+self.Account +'&bookType='+tabsId,
				    	method:'POST',
				    	type:'json',
				    	success : function(ret){
							sc.toast = sc.toast-1;
							sc.isZan = 0
				    	}
			    	})
				  
		    	}
		    },
		    onpeScxq:function(path){
		      this.$router.push(path);
		    },

		    onloading (event) {
		    	this.page+=1;
		    	this.flag=true;
		       // modal.toast({ message: 'loading', duration: 1 })
		        this.showLoading = 'show';
		        this.light(this.tabsIndex,this.tabsId);
		    }
		},
		created : function(){
			var self =this;
			self.isbn= this.$route.query.isbn;
			self.title= this.$route.query.title;
			//var titles;
			if(!self.isbn){
				this.isbn="";
			}else{
				self.ss=self.isbn;
			}
			if(!self.title){
				this.title="";
			}else{
				self.ss=self.title;
			}
	    	storage.getItem('username',function(e){  //从缓存中取userId
	        	self.Account = e.data;
		   		storage.getItem('schoolCode',function(e){  //从缓存中取userId
		            self.schoolId = e.data;
		            kwz.fetch({
					    url : '/app/book/search?loginAccount='+self.Account+'&keywords='+self.title+'&isbn='+self.isbn+'&page='+self.page+'&pageSize=8&schoolCode='+self.schoolId,
					    method:'POST',
					    type:'json',
					    success : function(ret){
					    	var datas = ret.data.result||[];
							if(ret.data.statusCode==200 && datas.length!=0){
				    			for(let i=0;i<datas.length;i++){
					    			self.sc_list.push(datas[i]);
					    		}
				    		}else if(ret.data.statusCode==404 && datas.length == 0 ){
				    			 modal.toast({ message: '已到底部', duration: 1 })
				    		}
				    		self.flag=false;
				    		self.showLoading = 'hide';
					    }

				    })
		        });  
		   	});
		}
	}
</script>

<style scoped>
	/*头部*/
	.loading {
  		width: 750px;
    	flex-direction: row;
   	 	align-items: center;
    	justify-content: center;
 	}
  	.indicator {
   		color: #888888;
	    font-size: 42px;
	    padding-top: 20px;
	    padding-bottom: 20px;
	    text-align: center;
 	 }
 	 /*
	.top{
		width: 750px;
		height: 98px;
		background-color: #fff;
		border-bottom-width: 1px;
		border-style: solid;
		border-color: #e7e7e7;
	}
	.topMain{
		flex-direction: row;
		align-items: center;
		font-size: 36px;
		line-height: 88px;
		width:600px;
		background-color: #f0f0f0;
		border-radius: 8px; 
		margin-bottom: 12px;
		margin-top: 12px;
		margin-left: 20px; 
		margin-right: 20px;

	}
	.pot_input{
		width: 490px;
		height:70px; 
		font-size: 32px; 
		background-color: #f0f0f0;
		border:none;
	}

	.look{
		width: 48px; 
		height: 48px; 
		margin-left: 20px; 
		margin-right: 20px;
	}
	*/
	.main{
		background-color: #fff; 
		padding-bottom: 30px;
	}
	.goback_r{
		position: absolute;
		top: 30px;
		right: 25px;
		width: 100px;
		height: 37px; 
		text-align: center;
		color: #666;
		font-size: 34px;
	}
	.nav{
		width: 750px; 
		height: 88px; 
		flex-direction: row;
		align-items: center;
		justify-content: center;
		border-color: #e7e7e7;
		border-bottom-width: 1px;
		border-style: solid;
		background-color: #fff;
	}
	.ydjy_list{
		width: 750px;  
		height: 290px; 
		flex-direction: row;
		align-items: center;
		background-color: #fff; 
		border-color: #ececec;
		border-bottom-width: 1px;
		border-style: solid;
		position: relative;
		z-index: 1;
	}
	.ydjy_l{
		width: 240px; 
		height:240px; 
		flex-direction: row;
		align-items: center;
		justify-content: center;
	}
	.ydjy_lPic{
		width: 190px;
		height: 240px; 
	}
	.ydjy_r{
		height: 240px; 
		width: 455px; 
	}
	.play{
		position: absolute; 
		background-color: #000;  
		width: 191px; 
		height:240px;   
		top:0; 
		left: 22px; 
		z-index: 88; 
		display: flex; 
		align-items: center; 
		justify-content: center; 
		filter:alpha(opacity=30);  /*支持 IE 浏览器*/
		-moz-opacity:0.30; /*支持 FireFox 浏览器*/
		opacity:0.30;  /*支持 Chrome, Opera, Safari 等浏览器*/	
	}
	.record{
		width: 455px; 
		height: 50px;
		font-size: 30px; 
		flex-direction: row;
		color: #999; 
	}
	.ico_22{
		width: 60px;
		height: 60px;
		position:absolute; 
		top:100px; 
		left:85px; 
		z-index:99;	
	}
	.b_list{
		flex-direction: row;
		font-size: 30px; 
		color: #666; 
		line-height: 55px;
	}
	.record_li{
		flex: 1; 
		flex-direction: row; 
		align-items: center; 
		justify-content: left;
	}
	.pic_see{
		width: 38px; 
		height: 27px; 
	}
	.pic_praise{
		width: 32px; 
		height: 28px; 
	}
	.hdzq_titil{
		flex-direction: row;
		color:#333; 
		font-size:36px; 
		height:60px;
		text-overflow:ellipsis; 
		lines:1;
	}
	.ts_label{
		font-size: 26px; 
		background-color:#d9e8fd; 
		color: #666; 
		padding-top: 4px;
		padding-bottom: 4px; 
		padding-left: 15px;
		padding-right: 15px;
		margin: 10px; 
		margin-left: 0; 
		border-radius: 5px;
	}
	.ydjy_state{
		 background-color: #f60;
		 color:#fff; 
		 font-size: 22px; 
		 position:absolute; 
		 left:22px;
		 top:10px;
		 padding-right: 15px;
		 padding-left: 15px;
		 padding-top: 8px;
		 padding-bottom: 8px;
		 z-index: 89;
		 border-top-right-radius:20px;
	     border-bottom-right-radius:20px;
	}
	.author{
		flex-direction: row;
		line-height: 40px;
	}
    .fontSize{
    	font-size: 32px;
    	color: #666;
    }
</style>