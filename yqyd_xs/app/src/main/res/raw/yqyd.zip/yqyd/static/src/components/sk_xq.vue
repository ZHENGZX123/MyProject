<template>
	<div style=" background-color: #fafafa; ">
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback"/>
			<text class="top_name" >{{book.bookName}}</text>
			<image src="../static/images/ico_heart01.png"  class="goback_r" />
			<!--<image src="../static/images/ico_2101.png" class="goback_r1" @click="openFx" />-->
		</div>
		<scroller>
		<!-- 书详情内容 -->
			<div class="b_name"><text style="color: #666;font-size: 36px; ">{{book.bookName}}</text></div>
			<div class="book">
				<image :src="book.bookPic"  class="b_img"></image>
				<div class="b_info">
					<text class="b_list">作者：{{book.author}}/著 </text>
					<text class="b_list">出版社：{{book.press}}</text>
					<text class="b_list">ISBN: {{book.isbn}} </text>
					<div style="flex-direction: row; justify-content: left;align-items: center;">
						<text class="ts_label">{{book.bookType}}</text>
						<!--<text class="ts_label">科普</text>
						<text class="ts_label">美国</text>-->
					</div>	
				</div>
			</div>
			<div class="jyzx">
				<text class="jyzx_title">专家导读</text>
			</div>
			<!-- 书简介 -->
			<div class="b_syn">
				<video :src="book.guideVoice" style=" width: 750px; height: 400px;" controls></video>
				<div class="b_cnt">
					<text class="b_title">编辑推荐</text>
					<text class="b_main" >{{book.editorIntro}}</text>
				</div>
				
				<div class="b_cnt">
					<text class="b_title">内容简介</text>
					<text class="b_main" >{{book.desc}}</text>
				</div>
				<div class="b_cnt">
					<text class="b_title">作者简介</text>
					<text class="b_main" >{{book.authorDesc}}</text>
				</div>
			</div>
		</scroller>
	</div>
</template>

<script>
    const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				b_syn: true,
				lt: false,
				book: 
					{/*src: '../static/images/book02.png', btime: '2017-01-01', etime: '2017-01-02', bname: '飞来的伤心梅', bath: '张琴声', bpre: '北京邮电',isbn:'9787547705063'*/},
			}
		},
		methods: {
			 goback () {
		      this.$router.go(-1);
		    },
		    openFx(){
		    	this.$router.push('/ydrw_xq/ydrw_xq_hare');
		    }
		},
		created: function(){
			 var self = this;
	           console.log(self.$route.query.type);
            	  kwz.fetch({
			    	url : '/app/book/'+self.$route.query.id+'?type='+self.$route.query.type,
			    	method:'GET',
			    	type:'json',
			    	//data:'loginAccount=12&token=123123&id=1',
			    	success : function(ret){
			    		var books = ret.data.result;
			    		self.book=eval(books);
			    		console.log(self.book);
			    	}
			  })
		},
	}
</script>

<style scoped>

	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:22px;
		left: 25px;
		width: 44px;
		height: 44px;
	}
	.goback_r{
		position: absolute;
		top:22px;
		right: 25px;
		width: 44px;
		height: 44px;
	}

	.goback_r1{
		position: absolute;
		top: 22px;
		right: 100px;
		width: 37px;
		height: 37px;
	}

	.book{
		flex-direction: row;
	    align-items: center;
		width: 750px;
		border-bottom-width: 1px;
		border-bottom-color: #f1f1ee;
		border-bottom-style: solid;
		padding-bottom: 24px;
		padding-top: 24px;
		padding-right: 30px;
		padding-left: 30px;
		overflow: hidden;
		background-color: #fff;
	}
	.b_img{
		width: 180px;
		height:220px;
		margin-right: 30px;
	}
	.b_info{
		width: 500px;
	}
	.b_main{
		font-size: 34px; 
		color: #666666; 
		margin-top: 20px; 
		line-height: 40px; 
		text-align: justify;
	}
	.b_list{
		font-size: 30px;
		color: #666; 
		line-height: 55px;
	}
	.b_name{
		width: 750px;
		height: 88px;
		background-color: #e7f1ff; 
		flex-direction: row;
		align-items: center;
		justify-content: center; 
	}
	.b_syn{
		width: 750px;
		background-color: #fff;
	}
	.b_cnt{
		width: 750;
		border-bottom-width: 1px;
		border-bottom-color: #f1f1ee;
		border-bottom-style: solid;
		padding-bottom: 60px;
		padding-top: 60px;
		padding-right: 30px;
		padding-left: 30px;
	}
	.b_title{ 
		text-align: left;
		font-size: 32px;
		color: #79a8ec;
	}
	.jyzx{
		width: 750px; 
		height: 88px;
		background-color: #fff;
		margin-top: 20px;
		border-color: #e7e7e7;
		border-bottom-width: 1px;
		border-style: solid;
		padding-right: 20px;
		padding-left: 20px;
		flex-direction: row;
		align-items: center;
	}
	.jyzx_title{
		color: #70a1e8;
		font-size: 36px;  
	}
	.title_img{
		background-color: #70a1e8; 
		margin-right: 1px; 
		width: 5px;
	}
	.ts_label{
		font-size: 26px;
		background-color:#d9e8fd; 
		color: #666; 
		padding-right: 15px;
		padding-left: 15px;
		padding-top: 4px;
		padding-bottom: 4px;
		margin: 10px;
		margin-left: 0; 
		border-radius: 5px;
	}
	.ico_22{
		width: 40px;
		height: 40px;
	}
	.ico_23{
		width: 33px;
		height: 40px;
	}
	.ico_24{
		width: 37px;
		height: 37px
	}
</style>