// import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import { sync } from 'vuex-router-sync'
import * as filters from './filters'
import mixins from './mixins'
import urls from '../static/js/url.js'


router.beforeEach((to, from, next) => {
    var fullPath = to.fullPath
    var globalEvent = weex.requireModule('globalEvent');
    if(globalEvent){
        var index = fullPath.indexOf('/index') != -1
        var sc = fullPath.indexOf('/sc') != -1
        var main = fullPath.indexOf('/main') != -1
        var login = fullPath.indexOf('/') != -1
        if(index || sc || main || login){
            globalEvent.addEventListener("clickback", function (e) {
                var sjevent = weex.requireModule('SJevent');
                if(sjevent){
                 sjevent.finish();
                }
            });
        }else{
            globalEvent.addEventListener("clickback", function (e) {
                window.history.go(-1)
            });
        }
    }
    next(true)
})

// sync the router with the vuex store.
// this registers `store.state.route`
sync(store, router)

Vue.prototype.globalurl=urls;
/*
var globalEvent = require('@weex-module/globalEvent');
globalEvent.addEventListener("clickback", function (e) {
        //toast: clickback is called

});*/
// register global utility filters.
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})

// register global mixins.
Vue.mixin(mixins)

// create the app instance.
// here we inject the router and store to all child components,
// making them available everywhere as `this.$router` and `this.$store`.
new Vue(Vue.util.extend({ el: '#root', router, store}, App))

router.push('/')
