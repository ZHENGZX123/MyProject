
<template>
	<div style=" background-color: #fafafa; ">
		<div class="top">
			<image src="../static/images/xs_pic_fh.png" class="goback" @click="goback"/>
			<text class="top_name" >阅读任务详情</text>
			<image src="../static/images/ico_heart01.png"  class="goback_r" />
			<!--<image src="../static/images/ico_2101.png" class="goback_r1"  @click="openFx" />-->
		</div>
		<scroller>
		<!-- 书详情内容 -->
			<div class="b_name"><text class="b_name1" >{{book.bookName}}</text></div>
			<div class="book">
				<image :src="book.bookPic"  class="b_img"></image>
				<div class="b_info">
					<text class="b_list">作者：{{book.author}}/著 </text>
					<text class="b_list">出版社：{{book.press}}</text>
					<text class="b_list">ISBN: {{book.isbn}} </text>
					<div style="flex-direction: row; justify-content: left;align-items: center;">
						<text class="ts_label">{{book.bookType}}</text>
					</div>	
				</div>
			</div>
			<div class="jyzx">
				<text class="jyzx_title">专家导读</text>
			</div>
			<!-- 书简介 -->
			<div class="b_syn">
				<video :src="book.guideVoice" play-status='play' style=" width: 750px; height: 400px; " controls="controls" @start="onstart" ></video>
				<div class="b_cnt">
					<text class="b_title">编辑推荐</text>
					<text class="b_main" >{{book.editorIntro}}</text>
				</div>
				
				<div class="b_cnt">
					<text class="b_title">内容简介</text>
					<text class="b_main" >{{book.desc}}</text>
				</div>
				<div class="b_cnt">
					<text class="b_title">作者简介</text>
					<text class="b_main" >{{book.authorDesc}}</text>
				</div>
			</div>
		</scroller>
		<div class="footes">
			<text class="footes_btn" v-if="pcShow" @click="opendhfx('/ydrw/xdhg?planId='+rwId+'&bookId='+bId+'&bookType='+rwtype+'&title='+bName)" >读后分享</text>
			<text class="footes_btn" @click="openkscg" v-if="cgShow">开始闯关</text>
			<text class="footes_btn" @click="openwdfx('/ydrw/wddhg?planId='+rwId+'&bookId='+bId)" v-if="pc">我的分享</text>
			<text class="footes_btn" @click="openwdcg" v-if="cg">我的闯关</text>
		</div>
	</div>
</template>

<script>
    const storage = weex.requireModule('storage');
    const modal = weex.requireModule('modal');
	import kwz from '../../static/js/Utils.js'
	export default {
		data(){
			return {
				b_syn: true,
				lt: false,
				book: 
					{/*src: '../static/images/book02.png', btime: '2017-01-01', etime: '2017-01-02', bname: '飞来的伤心梅', bath: '张琴声', bpre: '北京邮电',isbn:'9787547705063'*/},
				wwc:'',
				zrw:'',
				loginA:'',
			    rwId:'',
			    bId:'',
             	rwtype:0,
             	bName:'',
             	feeling:'',
             	test:'',
             	guideId:'',
			}
		},
		methods: {
			 goback () {
		      this.$router.go(-1);
		    },
		   /* openFx(){
		    	this.$router.push('/ydrw_xq/ydrw_xq_hare');
		    },*/
		    opendhfx(path){
		    	this.$router.push(path);
		    },
		    openwdfx(path){
				this.$router.push(path);
		    },
		    openkscg(){
		    	this.$router.push('/ydrw/kscg');
		    },
		    openwdcg(){
		    	this.$router.push('/ydrw/wdcg');
		    },
		    open:function(event){
		    	console.log(event.target.paused);
		    },
		    onstart (event) {

				console.log(event);
		    	var self=this;
		    	kwz.fetch({
				    url : '/app/book/play?guideId='+self.guideId,
				    method:'POST',
				    type:'json',
				    success : function(ret){
				    	debugger
				    	var guideId = ret.data.result;
				    	return guideId;
				    	console.log(guideId);
				    }
			    }) 
		    }
		},
		computed: {
			pcShow: function(){
				if((this.zrw=='2'||this.zrw=='1,2'||this.zrw=='2,1') && this.feeling=='0'){
					return true;
				}else{
					return false;
				}
			},
			cgShow: function(){
				if((this.zrw=='1'||this.zrw=='1,2'||this.zrw=='2,1') && this.test=='0'){
					return true;
				}else{
					return false;
				}
			},
			pc: function(){
				if((this.zrw=='2'||this.zrw=='1,2'||this.zrw=='2,1') && this.feeling=='1'){
					return true;
				}else{
					return false;
				}
			},
			cg: function(){
				if((this.zrw=='1'||this.zrw=='1,2'||this.zrw=='2,1') && this.test=='1'){
					return true;
				}else{
					return false;
				}
			}
		}
		,
		created: function(){
			
			var self = this;
			this.zrw=this.$route.query.access;
            this.feeling=this.$route.query.feelingFinish||'0';
            this.test=this.$route.query.testFinish||'0';
        /*    console.log('zrw----------'+this.zrw);
            console.log('feel----------'+this.feeling);
            console.log('test----------'+this.test);
*/
              //	this.loginA=this.$route.query.loginAccount;
			self.rwId=self.$route.query.planId;
            self.bId=self.$route.query.bookId;
            self.rwtype=self.$route.query.type;
            self.bName=self.$route.query.bookName;
			storage.getItem('username',function(e){  //从缓存中取userId
            self.loginA = e.data;
	          // console.log(self.$route.query.bookId);
	            kwz.fetch({
				    url : '/app/book/'+self.$route.query.bookId+'?type='+self.$route.query.type,
				    method:'GET',
				    type:'json',
				    success : function(ret){
				    	var books = ret.data.result;
				    	self.book=eval(books);
				    	self.guideId=eval(books.guideId);
				    		//console.log(self.book);
				    }
			    })
			 })

        }    
			 
	}
</script>
<style scoped>
	.top{ 
		width: 750px; 
		height: 88px; 
		background-color: #6fa1e8; 
		flex-direction: row; 
		align-items: center; 
		justify-content: center; 
	}
	.top_name{
		width: 500px;
		text-align: center;
		margin-left:120px;
		margin-right:120px;
		text-overflow: ellipsis;
		lines:1;
		font-size: 36px;
		color: #fff;
	}
	.goback{
		position: absolute;
		top:22px;
		left: 25px;
		width: 44px;
		height: 44px;
	}
	.goback_r{
		position: absolute;
		top:22px;
		right: 25px;
		width: 44px;
		height: 44px;
	}

	.goback_r1{
		position: absolute;
		top: 22px;
		right: 100px;
		width: 37px;
		height: 37px;
	}
	.book{
		flex-direction: row;
	    align-items: center;
		width: 750px;
		border-bottom-width: 1px;
		border-bottom-color: #f1f1ee;
		border-bottom-style: solid;
		padding-bottom: 24px;
		padding-top: 24px;
		padding-right: 30px;
		padding-left: 30px;
		overflow: hidden;
		background-color: #fff;
	}
	.b_img{
		width: 180px;
		height:220px;
		margin-right: 30px;
	}
	.b_info{
		width: 500px;
	}
	.b_main{
		font-size: 34px; 
		color: #666666; 
		margin-top: 20px; 
		line-height: 40px; 
		text-align: justify;
	}
	.b_list{
		font-size: 30px;
		color: #666; 
		line-height: 55px;
		text-overflow: ellipsis;
		lines:1;
	}
	.b_name{
		width: 750px;
		height: 88px;
		background-color: #e7f1ff; 
		flex-direction: row;
		align-items: center;
		justify-content: center; 
	}
	.b_name1{
		 width: 750px; 
		 color: #666;
		 font-size: 36px; 
		 text-overflow: ellipsis; 
		 lines:1; 
		 padding-left: 20px;
		 padding-right: 20px;
	}
	.b_syn{
		width: 750px;
		background-color: #fff;
		margin-bottom: 110px;
	}
	.b_cnt{
		width: 750;
		border-bottom-width: 1px;
		border-bottom-color: #f1f1ee;
		border-bottom-style: solid;
		padding-bottom: 60px;
		padding-top: 60px;
		padding-right: 30px;
		padding-left: 30px;
	}
	.b_title{ 
		text-align: left;
		font-size: 32px;
		color: #79a8ec;
	}

	.jyzx{
		width: 750px; 
		height: 88px;
		background-color: #fff;
		margin-top: 20px;
		border-color: #e7e7e7;
		border-bottom-width: 1px;
		border-style: solid;
		padding-right: 20px;
		padding-left: 20px;
		flex-direction: row;
		align-items: center;
	}
	.jyzx_title{
		color: #70a1e8;
		font-size: 36px;  
	}
	.title_img{
		background-color: #70a1e8; 
		margin-right: 1px; 
		width: 5px;
	}
	.ts_label{
		font-size: 26px;
		background-color:#d9e8fd; 
		color: #666; 
		padding-right: 15px;
		padding-left: 15px;
		padding-top: 4px;
		padding-bottom: 4px;
		margin: 10px;
		margin-left: 0; 
		border-radius: 5px;
	}
	.ico_22{
		width: 40px;
		height: 40px;
	}
	.ico_23{
		
		width: 33px;
		height: 40px;
	}
	.ico_24{
		width: 37px;
		height: 37px
	}
	.footes{
		position: absolute;
		z-index: 9999;
		left: 0;
		bottom: 0;
		width: 750px; 
		height: 98px; 
		background-color: #70a1e8;  
		flex-direction: row;
		justify-content: center;
		align-items:center;

	}
	.footes_btn{
		flex: 2;
		height: 70px; 
		line-height: 60px; 
		margin-left: 15px;
		margin-right: 15px; 
		flex-direction: row;
		justify-content: center;
		align-items: center; 
		border-color: #fff;
		border-width: 1px;
		border-style: solid;
		font-size: 34px; 
		border-radius: 8px;
		color: #fff; 
		text-align: center;
	}
</style>